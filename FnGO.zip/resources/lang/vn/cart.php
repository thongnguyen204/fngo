<?php

return [
    
    'Product'       => 'Sản phẩm',
    'Quantity'      => 'Số lượng',
    'Price'         => 'Giá',
    'Total'         => 'Tổng',
    'Success'       => 'Thêm thành công',
    'Fail'          => 'Đã có lỗi',
    'Checkout'      => 'Mua',
    'Update Cart'   => 'Cập nhật',
    'Deleted'       => 'Đã xóa sản phẩm',
    'Update'        => 'Đã cập nhật giỏ hàng',
    'Empty'         => 'GIỎ HÀNG ĐANG TRỐNG',
    'Add something' => 'Hãy thêm những sản phẩm bạn thích :)',
    'Cash'          => 'Tiền mặt',
    'Banking'       => 'Chuyển khoản ngân hàng',
    'paypal'        => 'Hoặc thanh toán qua PayPal',
    'Clear Cart'    => 'Xóa giỏ hàng',
    'Momo'          => 'Ví điện tử Momo',

]

?>