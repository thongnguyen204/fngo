<?php

return [
    
    
    'Name'      => 'Tên',
    'E-Mail Address' => 'E-Mail',
    'Phone number' => 'Số điện thoại',
    'Password' => 'Mật khẩu',
    'Confirm Password' => 'Xác nhận mật khẩu',
]

?>