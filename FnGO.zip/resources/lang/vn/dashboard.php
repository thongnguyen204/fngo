<?php

return [
    
    'Users'                 => 'Người dùng',
    'User Registrations'    => 'Người đăng kí mới',
    'New Orders'            => 'Đơn hàng mới',
    'Success orders'        => 'Đơn thành công',
    'Accounts'              => 'Tài khoản',
    'Top Hotels'           => 'Top khách sạn',
    'Top tours'             => 'Top tour du lịch',
    'Top Articles'          => 'Top bài viết',
]

?>

