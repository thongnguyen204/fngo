<?php

return [
    
    'Create'            => 'Tạo bài viết',
    'Empty comment'     => "Bài viết này hiện tại chưa có bình luận nào",
    'Login to comment'  => 'Đăng nhập để bình luận',
    
    'Search'            => 'Tìm bài viết',
    'Title'             => 'Tiêu đề',
    'Abstract'          => 'Giới thiệu',
    'Choose thumbnail'  => 'Chọn ảnh',
    'Content'           => 'Nội dung',
    'Read more'         => 'ĐỌC THÊM',
    'Update'            => 'Cập nhật bài viết',
    'Update button'     => 'Cập nhật',
]

?>