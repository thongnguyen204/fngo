<?php

return [
    
    
    'Remember Me'      => 'Lưu đăng nhập',
    'Forgot Your Password?'      => 'Quên mật khẩu ?',
    
]

?>