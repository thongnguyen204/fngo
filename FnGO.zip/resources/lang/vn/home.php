<?php

return [
    'top tour'  => 'TOUR NỔI BẬT',
    'top hotel'  => 'KHÁCH SẠN NỔI BẬT',
    'More'  => 'Xem thêm',
    'top article'  => 'BÀI VIẾT NHIỀU LƯỢT BÌNH LUẬN',
];

?>