<?php

return [


    'content' => 'Sự phát triển của internet giúp cho mọi người hiện giờ có thể đặt mua bất cứ thứ gì ngay lập tức sau khi tìm kiếm qua mạng internet. Do đó chúng tôi là <strong>FnGO</strong> đã làm ra website này để giúp các bạn tiết kiệm thời gian, chuẩn bị cho chuyến đi của mình tốt hơn, chỉ cần một vài thao tác đơn giản là bạn có thể sẵn sàng đi bất cứ đâu cùng chúng tôi.',
    'join'  => 'JOIN US',
]
?>