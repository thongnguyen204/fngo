<?php

return [
    
    'Admin'     => 'Admin',
    'Employee'  => 'Nhân viên',
    'User'      => 'Người dùng',
]

?>