<?php

return [
    
    'Name'              => 'Tên',
    "ID"                => 'ID',
    'Phone'             => 'Số điện thoại',
    "Search"            => "Tìm người dùng",
    'Update profile'    => 'Cập nhật thông tin thành công!',
    
]

?>