<?php

return [


    'Try'   => 'Chúng tôi nỗ lực mỗi ngày để đem đến những sản phẩm du lịch mới mẻ và chất lượng dịch vụ hoàn hảo tới bạn.',
    'Contacts'  => 'THÔNG TIN LIÊN HỆ',
    'Links' => 'LIÊN KẾT',
    'Payment'   => 'Phương thức thanh toán',
    'Intro'     => 'Website của chúng tôi',
    'About us'  => 'Về chúng tôi',
]
?>