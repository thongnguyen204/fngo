<?php

return [
    'Hotels'    => 'KHÁCH SẠN',
    'Tours'     => 'DU LỊCH',
    'Register'  => 'Đăng ký',
    'Login'     => 'Đăng nhập',
    'Articles'  => 'BÀI VIẾT',
    'Home'      => 'TRANG CHỦ',
]

?>