<?php

return [
    
    'Payment'           => 'PAYMENT DETAIL',
    'Offline'           => 'Using cash',
    'Banking'           => 'Bank transfer',
    'Offline-content'   => 'You can come to our office to pay your invoice.',
    'Address'           => 'Our address: ',

    'Bank'  => 'Nam a bank (NAB):',
    'Account Holder'    => 'Account holder: ',
    'Money' => 'Amount of money: ',
    'Banking-content'   => 'Banking content: ',
    'Price' => "Receipt's price",
    'Receipt ID'    => "Receipt's ID",
    'Paypal'    => 'Using Paypal',
    'Paypal content'    => 'You can use PayPal to pay any of your receipt.',
    'Momo'  => 'Using Momo e-wallet',
    'Momo content'    => 'Our website also support payment with Momo e-wallet.',
]

?>