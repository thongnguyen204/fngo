<?php

return [
    
    'Name'              => 'Name',
    'Receipt'           => 'My receipt',
    'Users manage'      => 'Users manage',
    'Receipts queue'    => 'Receipts queue',
    'Receipts manage'   => 'Receipts manage',
    'Tours manage'      => 'Tours manage' ,
    'Hotels manage'     => 'Hotels manage' ,
    'Articles manage'   => 'Articles manage',
    'Account settings'  => 'Account settings',
    'Logout'            => 'Logout',
    'Delete'            => 'Delete',
    'Profile'           => 'Profile',
    'Gender'            => 'Gender',
    'Male'              => 'Male',
    'Female'            => 'Female',
    'Other'             => 'Other',
    'Save Profile'      => 'Save Profile',
    'Choose avatar'     => 'Choose avatar',
    'Edit'              => 'Edit',
    'Home'              => 'Home',
    'Admin dashboard'   => 'Admin dashboard',
    'Income'            => 'Income statistic',
    'Income1'           => 'Income',
    'Day'               => 'Day',
    'Month'             => 'Month',
    'Year'              => 'Year',
    'Sort'              => 'Sort',
    'price-low-high'    => 'Price: low to high',
    'price-high-low'    => 'Price: high to low',
    'place'             => 'Place',
    'All'               => 'All',
]

?>