<?php

return [
    
    'Name'              => 'Name',
    "ID"                => "ID",
    'Phone'             => 'Phone number',
    "Search"            => "Search",
    'Update profile'    => 'Update profile success!',
]

?>