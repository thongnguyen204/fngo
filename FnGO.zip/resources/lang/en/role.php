<?php

return [
    
    'Admin'     => 'Admin',
    'Employee'  => 'Employee',
    'User'      => 'User',
]

?>