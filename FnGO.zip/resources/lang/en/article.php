<?php

return [
    
    'Create'            => 'Create an article',
    'Empty comment'     => "This article doesn't have any comment yet, you can be the first",
    'Login to comment'  => 'Login to comment',
    'Search'            => 'Find an article',
    'Title'             => 'Title',
    'Abstract'          => 'Abstract',
    'Choose thumbnail'  => 'Choose thumbnail',
    'Content'           => 'Content',
    'Read more'         => 'READ MORE',
    'Update'            => 'Update an article',
    'Update button'     => 'Update',
]

?>