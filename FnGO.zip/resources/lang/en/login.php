<?php

return [
    
    
    'Remember Me'      => 'Remember Me',
    'Forgot Your Password?'      => 'Forgot Your Password?',
    
]

?>