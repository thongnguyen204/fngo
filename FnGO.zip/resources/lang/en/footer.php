<?php

return [


    'Try'   => 'We try our best everyday to bring the freshest tours, hotels and perfect services to you.',
    'Contacts'  => 'CONTACTS',
    'Links' => 'LINKS',
    'Payment'   => 'Payment methods',
    'Intro'     => 'Our website',
    'About us'  => 'About us',

]
?>