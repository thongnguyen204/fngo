<?php

return [
    'top tour'  => 'TOP TOUR',
    'top hotel'  => 'TOP HOTEL',
    'More'  => 'More',
    'top article'  => 'ARTICLE WITH MOST COMMENT',

];

?>