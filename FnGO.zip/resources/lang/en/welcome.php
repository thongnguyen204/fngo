<?php

return [
    'Hotels'    => 'HOTELS',
    'Tours'     => 'TOURS',
    'Register'  => 'Register',
    'Login'     => 'Login',
    'Articles'  => 'ARTICLES',
    'Home'      => 'HOME',
]

?>