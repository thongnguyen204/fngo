<?php

return [
    
    'Product'       => 'Product',
    'Quantity'      => 'Quantity',
    'Price'         => 'Price',
    'Total'         => 'Total',
    'Success'       => 'Cart added',
    'Fail'          => 'Something wrong',
    'Checkout'      => 'Checkout',
    'Update Cart'   => 'Update cart',
    'Deleted'       => 'Deleted',
    'Update'        => 'Cart updated',
    'Empty'         => 'YOUR CART IS EMPTY',
    'Add something' => 'Add any product you like :)',
    'Cash'          => 'Cash',
    'Banking'       => 'Bank Transfer',
    'paypal'        => 'Or checkout with PayPal',
    'Clear Cart'    => 'Clear Cart',
    'Momo'          => 'Momo e-wallet',
]

?>