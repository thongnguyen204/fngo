<?php

return [
    
    'Register'  => 'Register',
    'Login'     => 'Login',
    'Name'      => 'Name',
    'E-Mail Address' => 'E-Mail Address',
    'Phone number' => 'Phone number',
    'Password' => 'Password',
    'Confirm Password' => 'Confirm Password',
]

?>