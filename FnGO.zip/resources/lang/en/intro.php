<?php

return [


    'content' => 'The growth of the internet means that more people are now booking their trips directly, either online or by phone after researching on the internet. 
                    Therefore, we - <strong>FnGO</strong> build this website to help you guys save your time, prepare your vacation better, just a few steps with us then you ready to go.',
    'join'  => 'JOIN US',
]
?>