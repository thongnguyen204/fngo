
<?php

return [
    
    'Users'                 => 'Users',
    'User Registrations'    => 'User Registrations',
    'New Orders'            => 'New Orders',
    'Success orders'        => 'Success orders',
    'Accounts'              => 'Accounts',
    'Top Hotels'           => 'Top Hotels',
    'Top tours'             => 'Top Tours',
    'Top Articles'          => 'Top Articles',
]

?>