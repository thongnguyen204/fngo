<?php
namespace App\Services;


interface HomeServiceInterface{
    public function search($request);
}