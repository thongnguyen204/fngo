1. clone git
2. composer install
3. create .env using .env.example file with your mysql information
4. php artisan config:cache
5. php artisan migrate
6 .php artisan db:seed
7. php artisan serve


test account:

admin: admin@gmail.com
pwd: 123456


employee: employee@gmail.com
pwd: 123456

user: user@gmail.com
pwd: 123456

