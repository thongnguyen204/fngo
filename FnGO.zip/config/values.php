<?php

    return [

        'partner_code' => env('PARTNER_CODE','MOMOUR5V20211030'),
        'access_key' => env('ACCESSS_KEY','7qS9EiT0H88F9VJ0'),
        'secret_key' => env('SECRET_KEY','CNHk35tDgIlkcj0GqRyi3zo0QSlSa4DN'),

        // Add other values as you wish
    ];
