<?php $__env->startSection('dashboard'); ?>
<body>
    <div class="container">
    <h3><?php echo e(__('receipt.Receipt List')); ?></h3>
    <form style="margin-bottom: 20px" action="<?php echo e(route('receiptWaiting.search')); ?>" method="GET">
        <div style="margin-bottom: 0px" class="input-group searchBar">
            <input placeholder="<?php echo e(__('receipt.Search')); ?>" type="text" name="search" value="<?php echo e(request()->get('search')); ?>" class="form-control" placeholder="">
            <div class="input-group-append">
                <button style="width: 100px" class="btn btn-search btn-outline-secondary" type="submit"><i
                        class="bi bi-search"></i>
                </button>
            </div>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="searchOptions" id="inlineRadio1" value="id">
            <label class="form-check-label" for="inlineRadio1">ID</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="searchOptions" id="inlineRadio2" value="userid">
            <label class="form-check-label" for="inlineRadio2"><?php echo e(__("receipt.User's ID")); ?></label>
        </div>
    </form>
    <?php if($receipts->isEmpty()): ?>
        <?php echo e(__('receipt.Empty')); ?>

    <?php else: ?>
    <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div style="margin-top: 50px" class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-6">#<?php echo e($receipt->id); ?></div>
                <div class="col-6">
                    <div style="float: right" class="row">
                        <form action="<?php echo e(route('receipt.accept',$receipt)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary" type="submit">Accept</button>
                        </form>
                        <form action="<?php echo e(route('receipt.destroy',$receipt)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button style="margin-left: 10px" class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <?php echo e($receipt->created_at); ?>

                </div>
            </div>
        </div>
        <div class="">
            <?php $__currentLoopData = $receipt->receipt_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body border">
                    
                    <div class="row">
                        <div class="col-12 col-md-2">
                            <img class="img-thumbnail"  style="max-width: 100%;" loading="lazy" alt="hotek Image" class="img_fluid"
                            src="<?php echo e($detail->product->avatar); ?>">
                        </div>
                        <div class="col-12 col-md-10">
                            <div class="row">
                                <div class="col-12"> 
                                    <?php echo e($detail->product->name); ?>

                                </div>
                                <div class="col-12"> 
                                    x <?php echo e($detail->quantity); ?>

                                </div>
                                <div class="col-12"> 
                                    <?php echo e($detail->description); ?>

                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="card-footer">
            <div style="float: right;" class="row">
                <div  class="col-12">
                    <?php echo e(__('receipt.Total')); ?>: <?php echo e(($receipt->money($receipt->price_sum))); ?>

                        
                </div>
            </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </div>
    
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>