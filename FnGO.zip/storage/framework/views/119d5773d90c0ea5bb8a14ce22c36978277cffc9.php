<?php $__env->startSection('dashboard'); ?>

<link href="<?php echo e(asset('css/dashboard-content.css')); ?>" rel="stylesheet">



<div class="container-fluid">
    <h1 class="m-0">Dashboard</h1>
</div>
<div style="margin-left: 0px" class="content">
    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-user">
                <div class="inner">
                    <h3><?php echo e($countUser); ?></h3>
                    <p><?php echo e(__('dashboard.Users')); ?></p>
                </div>
                <div class="icon">
                    <i class="bi bi-people-fill"></i>
                </div>
                <a href="<?php echo e(route('users.index')); ?>" class="small-box-footer">
                    More info
                    <i class="bi bi-arrow-right-circle-fill"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-newUser">
                <div class="inner">
                    <h3><?php echo e($countNewUser); ?></h3>
                    <p><?php echo e(__('dashboard.User Registrations')); ?></p>
                </div>
                <div class="icon">
                    <i class="bi bi-person-plus-fill"></i>
                </div>
                <a href="#" class="small-box-footer">
                    More info
                    <i class="bi bi-arrow-right-circle-fill"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-order">
                <div class="inner">
                    <h3><?php echo e($countWaitingOrders); ?></h3>
                    <p><?php echo e(__('dashboard.New Orders')); ?></p>
                </div>
                <div class="icon">
                    <i class="bi bi-bar-chart-fill"></i>
                </div>
                <a href="#" class="small-box-footer">
                    More info
                    <i class="bi bi-arrow-right-circle-fill"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3><?php echo e($countPaidOrdersToday); ?></h3>
                    <p><?php echo e(__('dashboard.Success orders')); ?></p>
                </div>
                <div class="icon">
                    <i class="bi bi-cash-coin"></i>
                </div>
                <a href="#" class="small-box-footer">
                    More info
                    <i class="bi bi-arrow-right-circle-fill"></i>
                </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="bi bi-pie-chart-fill"></i>
                        <?php echo e(__('dashboard.Accounts')); ?>: <?php echo e($countAllUser); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <div class="tab-content p-0">
                        <div >
                            <canvas id="userChart" style=""></canvas>
                            <input type="hidden" id="countUser" value="<?php echo e($countUser); ?>">
                            <input type="hidden" id="countEmployee" value="<?php echo e($countEmployee); ?>">
                            <input type="hidden" id="countAdmin" value="<?php echo e($countAdmin); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="bi bi-bar-chart-steps"></i>
                        <?php echo e(__('dashboard.Top Hotels')); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <div class="tab-content p-0">
                        <div class="d-flex align-items-center barChart" style="min-height: 300px">
                            <canvas id="hotelChart" style=""></canvas>
                        </div>
                    </div>
                    <?php $__currentLoopData = $topshotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input class="hotel" type="hidden" data-name="<?php echo e($hotel->name); ?>" value="<?php echo e($hotel->purchases_number); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="bi bi-bar-chart-steps"></i>
                        <?php echo e(__('dashboard.Top tours')); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <div class="tab-content p-0">
                        <div class="d-flex align-items-center barChart" style="min-height: 300px">
                            <canvas id="tourChart" style=""></canvas>
                        </div>
                    </div>
                    <?php $__currentLoopData = $topstour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input class="tour" type="hidden" data-name="<?php echo e($tour->product_code); ?>" value="<?php echo e($tour->purchases_number); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="bi bi-bar-chart-steps"></i>
                        <?php echo e(__('dashboard.Top Articles')); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <div class="tab-content p-0">
                        <div class="d-flex align-items-center barChart" style="min-height: 300px">
                            <canvas id="articleChart" style=""></canvas>
                        </div>
                    </div>
                    <?php $__currentLoopData = $topArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input class="article" type="hidden" data-name="<?php echo e($article->title); ?>" value="<?php echo e($article->comment_number); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="<?php echo e(asset('js/dashboard-chart.js')); ?>" defer></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>