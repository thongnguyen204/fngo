<?php $__env->startSection('dashboard'); ?>



<link href="<?php echo e(asset('css/receipt.css')); ?>" rel="stylesheet">

<div class=" mt-3 pt-3 container bg-white rounded wrapper">
    <?php echo $__env->make('admin.user.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="btn-toolbar my-2" role="toolbar" aria-label="Toolbar with button groups">
        <?php if(!Auth::guest() && Auth::user()->role->name == 'admin'): ?>
            
        <?php endif; ?>
        <div class="btn-group mr-2" role="group" aria-label="First group">
            <a href="<?php echo e(route('user.roleSort','all')); ?>" class="btn btn-outline-primary">Show all</a>
        </div>
        
        <div class="btn-group mr-2" role="group" aria-label="Second group">
            <a href="<?php echo e(route('user.roleSort','user')); ?>" class="btn btn-outline-secondary">Only user</a>
        </div>
        
        <div class="btn-group mr-2" role="group" aria-label="Third group">
            <a href="<?php echo e(route('user.roleSort','employee')); ?>" class="btn btn-outline-success">Only Employee</a>
        </div>
        
        <div class="btn-group" role="group" aria-label="Fourth group">
            <a href="<?php echo e(route('user.roleSort','admin')); ?>" class="btn btn-outline-danger">Only Admin</a>
        </div>
    </div>
    <?php if(!$users): ?>
        <?php echo e(__('user.Empty')); ?>

    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">User's ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col"></th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><a href="<?php echo e(route('users.edit',[$user])); ?>"><?php echo e($user->id); ?></a></th>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        <td>
                            <form onsubmit="return confirm('Delete this account?');" action="<?php echo e(route('users.destroy',[$user->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <div class="">
                                    <button class="btn btn-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                                </div>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    

</div>


<script>
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>