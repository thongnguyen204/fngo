<?php if(auth()->guard()->guest()): ?>
<div class="input-comment">
    <a href="<?php echo e(route('login')); ?>"><?php echo e(__('article.Login to comment')); ?></a> 
</div>
<?php endif; ?>

<?php if(!$have_comment): ?>
<div class="input-comment"><?php echo e(__('article.Empty comment')); ?></div>
<?php else: ?>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="comment-wrapper rounded commented-section mt-2">
        <div class="row">
            <div class="col">

            </div>
            <div class="col d-flex justify-content-end">
            
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->role_id== 1): ?>
                    
                    <button onclick="deleteComment()" type="button" class="btn btn-danger"><i class="bi bi-x-lg"></i></button>
                    
                <?php endif; ?>
            <?php endif; ?>
            
            </div>
        </div>
        <div class="row avatar-name">
            
            <div class="col">
                
                <img class="img-responsive rounded-circle" src="<?php echo e($comment->user->avatar); ?>" width="38">
                <span  class="user-name"><?php echo e($comment->user->name); ?></span>
                
            </div>
            <div class="col d-flex align-items-center justify-content-end">
                <div class=" "><?php echo e($comment->day()); ?></div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div>
                    <?php echo e($comment->content); ?>

                    <input type="hidden" data-articleCommentID="<?php echo e($comment->id); ?>" value="<?php echo e($comment->id); ?>" id="commentID">
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>