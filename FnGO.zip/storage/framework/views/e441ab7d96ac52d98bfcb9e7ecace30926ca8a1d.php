<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('hotel.update',$hotel->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <table>
        <tr>
            <td><label for="name">Name: </label></td>
            <td><input type="text" name="name" 
                value="<?php echo e($hotel->name); ?>"/></td>
        </tr>
        <tr>
            <td><label for="avg_price">Average price: </label></td>
            <td><input type="text" name="avg_price" 
                value="<?php echo e($hotel->price_avg); ?>"/></td>
        </tr>
        <tr>
            <td></td>
            <td><button type="submit">Update</button></td>
        </tr>
    </table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>