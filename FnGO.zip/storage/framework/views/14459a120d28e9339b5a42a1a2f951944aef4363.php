<form action="<?php echo e(route('user.update',$user->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div>
        <label for="name">Name: </label>
        <input type="text" name="name" 
        value="<?php echo e($user->name); ?>"/>
    </div>

    <div>
        <label for="email">Email: </label>
        <input type="text" name="email" 
        value="<?php echo e($user->email); ?>"/>
    </div>
    <div>
        <button type="submit">update</button>
    </div>
</form>