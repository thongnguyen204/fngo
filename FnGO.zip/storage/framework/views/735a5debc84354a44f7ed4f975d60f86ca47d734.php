<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/tour.css')); ?>" rel="stylesheet">

<div class="container create-form-container rounded bg-white ">
    <div class="blue-bar rounded-top"></div>
    <h1 class="d-flex justify-content-center">
        <span style="padding-left: 20px;padding-right: 20px;" class="sub-title-warpper"><?php echo e(__('tour.Edit')); ?></span>
    </h1>
    <form style="padding: 20px" action="<?php echo e(route('tour.update',$tour)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" id="lang" name="lang" value="<?php echo e(app()->getLocale()); ?>">
        <input type="hidden" value="<?php echo e($tour->subTour->count()); ?>" name="day_number" id="day_number"/>
        <input type="hidden" id="formType" name="formType" value="edit">
            <div class="form-group row">
                <div class="col">
                    <label for="name"><?php echo e(__('tour.Title')); ?></label>
                    <input class="form-control" type="text" name="name" value="<?php echo e($tour->name); ?>"/>
                    <?php if($errors->has('name')): ?>
                        <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

            <input type="hidden" value="<?php echo e($tour->subTour->count()); ?>" name="day_number" id="day_number"/>
                
            <div class="form-group row">
                <div class="col">
                    <label for="price"><?php echo e(__('tour.Price')); ?></label>
                    <input class="form-control" type="number" name="price" value="<?php echo e($tour->price); ?>"/>
                    <?php if($errors->has('price')): ?>
                        <?php $__currentLoopData = $errors->get('price'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col">
                    <label for="cityProvince">Province / City</label>
                    <select class="form-control" id="cityProvince" name="cityProvince">
                        <?php $__currentLoopData = $cty_province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cityProvince): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                <?php if($tour->city_province_id == $cityProvince->id): ?>
                                    selected
                                <?php endif; ?>
                            value="<?php echo e($cityProvince->id); ?>"><?php echo e($cityProvince->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="col">
                    <label for="passenger_num"><?php echo e(__('tour.Number of passengers')); ?></label>
                    <input class="form-control" type="number" min="0" name="passenger_num" value="<?php echo e($tour->passenger_num); ?>"/>
                    <?php if($errors->has('passenger_num')): ?>
                        <?php $__currentLoopData = $errors->get('passenger_num'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col">
                    <label for="day_number"> <?php echo e(__('tour.Days')); ?></label></td>
                    <input class="form-control" type="number" min="0" name="day_number" value="<?php echo e($tour->day_number); ?>"/>
                    <?php if($errors->has('day_number')): ?>
                        <?php $__currentLoopData = $errors->get('day_number'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-group row">
                <div class="col">
                    <label for="departure_date"><?php echo e(__('tour.Departure date')); ?></label></td>
                    <input class="form-control" type="date" name="departure_date" value="<?php echo e($tour->departure_date); ?>"/>
                    <?php if($errors->has('departure_date')): ?>
                        <?php $__currentLoopData = $errors->get('departure_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group  row">
                <div class="col">
                    <input class="form-control " type="number" min="0" max="23" placeholder="Hour" name="departure_hour" value="<?php echo e($tour->departure_hour); ?>"/>
                </div>
                
                <div class="col">
                    <input class="form-control " type="number" min="0" max="59" placeholder="Minute" name="departure_minute" value="<?php echo e($tour->departure_minute); ?>"/>
                </div>
            
                <?php if($errors->has('departure_hour')): ?>
                    <?php $__currentLoopData = $errors->get('departure_hour'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if($errors->has('departure_minute')): ?>
                <?php $__currentLoopData = $errors->get('departure_minute'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <strong><?php echo e($error); ?></strong>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </div>
            
            <div class="form-group row">
                <div class="col">
                    <label for="departure_place"><?php echo e(__('tour.Departure place')); ?></label>
                    <input class="form-control" type="text" name="departure_place" value="<?php echo e($tour->departure_place); ?>"/>
                    <?php if($errors->has('departure_place')): ?>
                        <?php $__currentLoopData = $errors->get('departure_place'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <div class="col">
                    <label for="content"><?php echo e(__('tour.Content')); ?></label>
                    <textarea class="form-control" name="content" rows="10" cols="50"><?php echo e($tour->content); ?></textarea>
                    <?php if($errors->has('content')): ?>
                        <?php $__currentLoopData = $errors->get('content'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        
        <div class="custom-file">
            <input type="file" class="custom-file-input" id="customFile" name="avatar" value="" >
            <label class="custom-file-label" for="customFile"><?php echo e(__('common.Choose avatar')); ?></label>
            <?php if($errors->has('mainImg')): ?>
                <?php $__currentLoopData = $errors->get('mainImg'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
            
        <h2 class="d-flex justify-content-center"><?php echo e(__('tour.Schedule')); ?></h2>
        <div id="day">
            <?php $__currentLoopData = $tour->subTour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="<?php echo e($subTrip->day); ?>">
                <div class="form-group row">
                    <div class="col">
                        <label for="title"><?php echo e(__('tour.Title')); ?></label></td>
                        <input class="form-control"  type="text" value="<?php echo e($subTrip->title); ?>" name="subTripTitle[<?php echo e($subTrip->day); ?>]" size="40"/>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col">
                        <label class="col-12" for="content"><?php echo e(__('tour.Content')); ?></label></td>
                        <textarea id="subTripContent" class="ckeditor col-12"  name="subTripContent[<?php echo e($subTrip->day); ?>]" rows="10" cols="50"><?php echo e($subTrip->content); ?></textarea></td>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-end">
            <button style="margin-right: 20px" class="btn btn-primary" type="button" id="addDayEdit"><?php echo e(__('tour.Add')); ?></button>
            <button style="margin-right: 20px" class="btn btn-secondary" type="button" id="removeDayEdit"><?php echo e(__('tour.Remove')); ?></button>
            <button style="margin-right: 20px" class="btn btn-success" type="submit"><?php echo e(__('tour.Update')); ?></button>
            <a href="<?php echo e(route('tour.show',$tour)); ?>" style="margin-right: 0px" class="btn btn-success" type="submit"><?php echo e(__('tour.Back')); ?></a>
        </div>
    </form>
</div>

<script src="<?php echo e(asset('js/tourEdit/script.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>