<?php $__env->startSection('content'); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Receipt Detail</title>
</head>
<body>
    <h1>Receipt Detail</h1>
    <a href="<?php echo e(route('receipt-detail.create')); ?>">Add room</a>
    <table>
        <tr>
            <th >Service ID</th>
            <th>category</th>
            <th>Price</th>
            <th>Quantity</th>
            <th></th>
        </tr>
    <?php $__currentLoopData = $receiptDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiptDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($receiptDetail->service_id); ?></td>
        <td><?php echo e($receiptDetail->category); ?></td>
        <td><?php echo e($receiptDetail->unit_price); ?></td>
        <td><?php echo e($receiptDetail->quantity); ?></td>
        <td><a href="<?php echo e(route('receipt-detail.edit'
        ,$receiptDetail)); ?>">edit</a></td>
        <td>
            <form action="<?php echo e(route('receipt-detail.destroy',$receiptDetail)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit">Delete</button>
            </form>
        </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($receiptDetails->links()); ?>

    <a href="<?php echo e(route('receipt.index')); ?>">Back to receipts</a>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>