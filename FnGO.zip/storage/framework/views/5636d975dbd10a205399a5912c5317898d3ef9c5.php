<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">


<!-- The sidebar -->
<div class="sidebar">
  <?php if(Auth::user()->role->name == 'admin'): ?>
  <a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>">
    <i class="bi bi-cpu-fill"></i> 
    Dashboard
  </a>
  <a class="nav-link" href='<?php echo e(route('users.index')); ?>'>
    <i class="bi bi-people-fill"></i>
    <?php echo e(__('common.Users manage')); ?>

  </a>
  <?php endif; ?>
  

  

  <a class="nav-link" href='<?php echo e(route('receipt.waiting')); ?>'>
    <i class="bi bi-check2-circle"></i>
    <?php echo e(__('common.Receipts queue')); ?>

  </a>
  <a class="nav-link" href='<?php echo e(route('receipt.indexAccepted')); ?>'>
    <i class="bi bi-receipt-cutoff"></i>
    <?php echo e(__('common.Receipts manage')); ?>

  </a>
  
  
  <button class="dropdown-btn">
    <i class="bi bi-graph-up"></i>
    <?php echo e(__('common.Income')); ?>

    
  </button>

  <div class="dropdown-container">
    <a href="<?php echo e(route('income.currentDay')); ?>"><?php echo e(__('common.Day')); ?></a>
    <a href="<?php echo e(route('income.currentMonth')); ?>"><?php echo e(__('common.Month')); ?></a>
    <a href="<?php echo e(route('income.currentYear')); ?>"><?php echo e(__('common.Year')); ?></a>
  </div>
  
</div>
  
  <!-- Page content -->
  <div class="content">
    <main>
      <?php echo $__env->yieldContent('dashboard'); ?>
  </main>
  </div>


<script src="<?php echo e(asset('js/dashboard.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>