<?php $__env->startSection('content'); ?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@600&display=swap" rel="stylesheet">

<link href="<?php echo e(asset('css/hotel.css')); ?>" rel="stylesheet">

    <div style="max-width: 1300px;" class="container">
        
        <form action="<?php echo e(route('hotel.index')); ?>" method="GET">
            <div class="input-group mb-3 searchBar">
                <input placeholder="<?php echo e(__('hotel.Search')); ?>" type="text" name="search" value="<?php echo e(request()->get('search')); ?>" class="form-control"
                    placeholder="">
                <div class="input-group-append">
                    <button style="width: 100px" class="btn btn-search btn-outline-secondary" type="submit"><i
                            class="bi bi-search"></i></button>
                </div>
            </div>
        </form>
        <div class="row">
            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card col-md-4">
                <div class="card-body">
                    <a href="<?php echo e(route('hotel.show',$hotel)); ?>">
                        <img loading="lazy" alt="hotek Image" class="img_fluid rounded pictrure"
                            src="<?php echo e($hotel->avatar); ?>">
                    </a>
                </div>
                <div class="card-body hotel-info">
                    <div class="row">
                        <a href="<?php echo e(route('hotel.show',$hotel)); ?>">
                            <div class="col-md-12 hotel-name-index"><?php echo e($hotel->name); ?></div>
                        </a>
                    </div>

                    <div class="row" >
                        <div class="col-6 col-sm-6 col-md-12 col-lg-6">
                            <i class="bi bi-geo-alt-fill"></i>
                            <?php echo e($hotel->CityProvince->name); ?>

                        </div>
                        <div id="money" class="float-right col-6 col-sm-6 col-md-12 col-lg-6">
                            <div class="float-right" style="width: 130px"><?php echo e($hotel->money($hotel->price)); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($hotels->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>