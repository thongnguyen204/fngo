<?php $__env->startSection('content'); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@600;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
<link href="<?php echo e(asset('css/hotel.css')); ?>" rel="stylesheet">
<style>
    
</style>
<div style="max-width: 1300px" class="container">
    <form action="<?php echo e(route('hotel.index')); ?>" method="GET">
        <div class="input-group mb-3 searchBar">
            <input type="text" placeholder="<?php echo e(__('hotel.Search')); ?>" name="search" value="<?php echo e(request()->get('search')); ?>"
                class="form-control" placeholder="">
            <div class="input-group-append">
                <button style="width: 100px" class="btn btn-search btn-outline-secondary" type="submit"><i
                        class="bi bi-search"></i></button>
            </div>
        </div>
    </form>
</div>
<div style="max-width: 1300px;padding: 20px;" class="container rounded bg-white">
    <div class="admin-button">
        <div class="row">
            <a class="btn btn-success col admin-button" href="<?php echo e(route('hotel.create')); ?>"><i class="bi bi-plus-lg"></i></a>
            <a class="btn btn-primary col admin-button" href="<?php echo e(route('hotel.edit',$hotel)); ?>"><i class="bi bi-pencil-square"></i></a>
            <div style="padding: 0px"  class="col admin-button" >
                <form action=" <?php echo e(route('hotel.destroy',$hotel)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button style="width: 100%" class="btn btn-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                </form>
            </div>
        </div>
    </div>
    <h2 class="hotel-name-detail"><?php echo e($hotel->name); ?></h2>
    <div>
        <i class="bi bi-pin-map-fill"></i> <?php echo e($hotel->address); ?>

    </div>
    <hr style="height:2px;border-width:0;color:gray;background-color:#e6eaed">
    <div class="row">
        <div class="col-md-12">
            <div class="">
                <img style="width: 100%;" loading="lazy" alt="tour Image" class="img_fluid rounded"
                    src="<?php echo e($hotel->avatar); ?>">
            </div>
        </div>
    </div>
<div style="margin-top: 20px" class="d-flex justify-content-end">
    <a class="btn btn-success" href="<?php echo e(route('room.create',$hotel)); ?>">Add room type</a>
</div>
</div>

<?php $__currentLoopData = $hotel->roomtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="max-width: 1300px;margin-top: 20px;padding: 20px;" class="container rounded bg-white">
    <div class="room-type-warpper">
        <div class="admin-button">
            <div class="row">
                <a class="btn btn-primary col admin-button" href="<?php echo e(route('room.edit',$roomtype)); ?>"><i class="bi bi-pencil-square"></i></a>
                <div style="padding: 0px"  class="col admin-button" >
                    <form action=" <?php echo e(route('room.destroy',$roomtype)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button style="width: 100%" class="btn btn-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                    </form>
                </div>
            </div>
        </div>
        <h3><?php echo e($roomtype->name); ?></h3>
        <div class="row">
            <div style="margin-bottom: 10px" class="col-md-4 d-flex justify-content-center">
                <img style="width: 100%;" loading="lazy" alt="room image" class="img_fluid rounded"
                    src="<?php echo e($roomtype->avatar); ?>">
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-6 col-md-4">
                        <i class="fas fa-bed"></i>
                        <?php if($roomtype->bed == '1-2'): ?>
                        1 <?php echo e(__('hotel.Double bed')); ?>

                        <?php else: ?>
                        <?php if($roomtype->bed == '1-1'): ?>
                        1 <?php echo e(__('hotel.Single bed')); ?>

                        <?php else: ?>
                        <?php if($roomtype->bed == '2-1'): ?>
                        2 <?php echo e(__('hotel.Single bed')); ?>

                        <?php else: ?>
                        2 <?php echo e(__('hotel.Double bed')); ?>

                        <?php endif; ?>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-6 col-md-4">
                        <i class="bi bi-people-fill"></i>&nbsp
                        <?php echo e($roomtype->max_person); ?> <?php echo e(__('hotel.Guest')); ?>

                    </div>
                </div>
                <hr style="height:2px;border-width:0;color:gray;background-color:#e6eaed">
                <div class="row">
                    <div class="col-4 col-md-4">
                        <?php if($roomtype->breakfast == false): ?>
                        <i class="bi bi-backspace-reverse"></i>
                        <?php echo e(__('hotel.Without breakfast')); ?>

                        <?php else: ?>
                        <i class="fas fa-utensils"></i>
                        <?php echo e(__('hotel.Free breakfast')); ?>

                        <?php endif; ?><br>
                        <i class="bi bi-wifi"></i>
                        <?php echo e(__('hotel.Free wifi')); ?>

                    </div>
                    <div class="col-4 col-md-4">
                        <?php if($roomtype->refund == false): ?>
                        <i class="bi bi-backspace-reverse"></i>
                        <?php echo e(__('hotel.Non-refundable')); ?>

                        <?php else: ?>
                        <i class="bi bi-cash-stack"></i>
                        <?php echo e(__('hotel.Refundable')); ?>

                        <?php endif; ?><br>
                    </div>
                    <div class=" col-4 col-md-4">
                        <div class="float-right">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col"> </div>
                    <div class="col-12">
                        <div class="">
                            <div class="float-right">
                                <span id="money" style="">
                                    <?php echo e($roomtype->money($roomtype->price)); ?>

                                </span><br>
                                <span class="float-right">/ <?php echo e(__('hotel.room')); ?> / <?php echo e(__('hotel.night')); ?>

                                </span>
                            </div>
                            <form action="<?php echo e(route('hotelbooking.create',$roomtype)); ?>" method="GET">
                                <button id="bookbtn" type="submit" class="btn btnAddCart"><?php echo e(__('hotel.Book now')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    function addCart(id) {

        $.ajax({
            url: "/addCart/" + id,
            type: 'GET',

        }).done(function (respone) {
            var icon = '<span class="bi bi-bag-check test"></span>';
            alertify.notify(icon + " " + respone, 'custom');
        });

        $.ajax({
            url: "/cartQuantity",
            type: 'GET',c
        }).done(function (respone) {
            $('#CartCount').text(respone);
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>