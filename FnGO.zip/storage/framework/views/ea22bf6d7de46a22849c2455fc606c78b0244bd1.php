
<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/tour.css')); ?>" rel="stylesheet">


<div style="max-width: 1300px;" class="container">
    <form action="<?php echo e(route('tour.index')); ?>" method="GET">
        <div class="input-group mb-3 searchBar">
            <input placeholder="<?php echo e(__('tour.Search')); ?>" type="text" name="search" value="<?php echo e(request()->get('search')); ?>" class="form-control" placeholder="">
            <div class="input-group-append">
                <button style="width: 100px" class="btn btn-search btn-outline-secondary" type="submit"><i
                        class="bi bi-search"></i>
                </button>
            </div>
        </div>
    </form>
    <div class="row">
        <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card col-md-4">
            <div class="card-body">

                <a href="<?php echo e(route('tour.show',$trip)); ?>">
                    <img loading="lazy" alt="tour Image" class="img-fluid rounded pictrure" src="<?php echo e($trip->avatar); ?>">
                </a>

            </div>
            <div class="card-body tour-info">
                <div class="row">
                    <a href="<?php echo e(route('tour.show',$trip)); ?>">
                        <div class="col-md-12"><?php echo e($trip->name); ?></div>
                    </a>
                </div>

                <div class="row">
                    <div class="col-6 col-sm-6 col-md-12 col-lg-6">
                        <i class="bi bi-geo-alt-fill"></i>TPHCM
                    </div>
                    <div id="money" class="float-right col-6 col-sm-6 col-md-12 col-lg-6">
                        <div class="float-right" style="width: 130px"><?php echo e($trip->money($trip->price)); ?></div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($trips->links()); ?>

</div>

<script>
    function addCart(id) {
        var currentLocation = window.location;
        console.log(currentLocation);
        $.ajax({
            url: "addCart/" + id,
            type: 'GET',
        }).done(function (respone) {
            var icon = '<span class="bi bi-bag-check test"></span>';
            alertify.notify(icon + " " + respone, 'custom');
        });

        $.ajax({
            url: "cartQuantity",
            type: 'GET',
        }).done(function (respone) {
            $('#CartCount').text(respone);
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>