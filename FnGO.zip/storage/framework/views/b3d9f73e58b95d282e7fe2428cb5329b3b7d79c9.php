<?php $__env->startSection('content'); ?>


<body>
    <div class="container">
    <h1>Rooms</h1>
    <table class="table">
        <tr>
            <th >Room number</th>
            <th>Type</th>
            <th>Max person</th>
            <th>Price</th>
            <th></th>
            <th></th>
        </tr>
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($room->room_number); ?></td>
        <td><?php echo e($room->type->name); ?></td>
        <td><?php echo e($room->type->max_person); ?></td>
        <td><?php echo e($room->type->price_per_night); ?></td>
        <td><a href="">details</a></td>
        <td>
            <form action="<?php echo e(route('orderForm',$room)); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary" type="submit">Order</button>
            </form>
        </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($rooms->links()); ?>

    
</div>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>