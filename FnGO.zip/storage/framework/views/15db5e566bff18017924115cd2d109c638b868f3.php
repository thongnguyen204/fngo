<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('users.update',[$user])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>



<div  class="container rounded bg-white mt-5 mb-5">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-5 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" id="avatar" width="150px" src="<?php echo e($user->avatar); ?>"><span class="font-weight-bold"><?php echo e($user->name); ?></span><span class="text-black-50"><?php echo e($user->email); ?></span><span> </span></div>
            
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="customFile" name="avatar" >
                <label class="custom-file-label" for="customFile"><?php echo e(__('common.Choose avatar')); ?></label>
                <?php if($errors->has('avatar')): ?>
                    <?php $__currentLoopData = $errors->get('avatar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-5 border-right">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="col-md-12 "><?php echo e(__('common.Profile')); ?></h4>
                </div>
                <div class="row mt-2">
                    <div class="col-md-12"><label class="labels"><?php echo e(__('common.Name')); ?></label><input type="text" name="name" class="form-control" placeholder="" value="<?php echo e($user->name); ?>"></div>
                    <?php if($errors->has('name')): ?>
                        <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12">
                        <label class="labels">Email</label><input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>">
                        <?php if($errors->has('email')): ?>
                            <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12"><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <label class="labels"><?php echo e(__('register.Phone number')); ?></label><input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>">
                        <?php if($errors->has('phone')): ?>
                        <?php $__currentLoopData = $errors->get('phone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <label class="labels" for="gender"></label>
                        <select class="form-control" id="gender" name="gender">
                            <option value="none" selected><?php echo e(__('common.Gender')); ?></option>
                            <option <?php if($user->gender == 'male'): ?>
                                selected
                            <?php endif; ?> value="male" ><?php echo e(__('common.Male')); ?></option>
                            <option <?php if($user->gender == 'female'): ?>
                                selected
                            <?php endif; ?> value="female" ><?php echo e(__('common.Female')); ?></option>
                            <option <?php if($user->gender == 'other'): ?>
                                selected
                            <?php endif; ?> value="other" ><?php echo e(__('common.Other')); ?></option>
                        </select>
                        
                    </div>
                    
                    
                </div>
                <div class="row mt-3">
                
                </div>
                
                <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="submit"><?php echo e(__('common.Save Profile')); ?></button></div>
            </div>
        </div>
        
    </div>
</div>
</div>
</div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>