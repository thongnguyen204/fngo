<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col"><?php echo e(__("tour.ID")); ?></th>
                <th scope="col"><?php echo e(__('tour.Product_code')); ?></th>
                <th scope="col"><?php echo e(__('tour.Name')); ?></th>
                <th scope="col"><?php echo e(__('tour.Price')); ?></th>
                <th scope="col"><?php echo e(__('tour.Created_at')); ?></th>
                <th scope="col"></th>
                <th scope="col"></th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($tour->id); ?></th>
                    <td><?php echo e($tour->product_code); ?></td>
                    <td><a href="<?php echo e(route('tour.show',$tour)); ?>"><?php echo e($tour->name); ?></a></td>
                    <td><?php echo e($tour->money($tour->price)); ?></td>
                    <td><?php echo e($tour->created_at); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('tour.edit',[$tour])); ?>"><i class="bi bi-pencil-fill"></i></a></td>
                    <td>
                        <button onclick="deleteTour(<?php echo e($tour->id); ?>)" class="btn btn-danger" type="button"><i class="bi bi-trash-fill"></i></button>    
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>