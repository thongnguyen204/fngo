<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col"><?php echo e(__("user.ID")); ?></th>
                <th scope="col"><?php echo e(__('user.Name')); ?></th>
                <th scope="col">Email</th>
                <th scope="col"><?php echo e(__('user.Phone')); ?></th>
                <th scope="col"></th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><a href="<?php echo e(route('users.edit',[$user])); ?>"><?php echo e($user->id); ?></a></th>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td>
                        <form onsubmit="return confirm('Delete this account?');" action="<?php echo e(route('users.destroy',[$user->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <div class="">
                                <button class="btn btn-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                            </div>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>