

<?php $__env->startSection('content'); ?>


<link href="<?php echo e(asset('css/hotel.css')); ?>" rel="stylesheet">


<div class="container create-form-container rounded bg-white">
    <div class="green-bar rounded-top"></div>
    <h1 class="d-flex justify-content-center">
        <span style="padding-left: 20px;padding-right: 20px;" class="sub-title-warpper"><?php echo e(__('hotel.Create')); ?></span>
    </h1>
    <form style="padding: 20px" action="<?php echo e(route('hotel.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="formType" name="formType" value="create">
        <div class="form-group row">
            <div class="col">
                <label for="name"><?php echo e(__('hotel.Name')); ?></label>
                <input class="form-control" type="text" name="name" value="<?php echo e(old('name')); ?>" />
                <?php if($errors->has('name')): ?>
                    <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-8">
                <label for="address"><?php echo e(__('hotel.Address')); ?></label>
                <input class="form-control" type="text" name="address" value="<?php echo e(old('address')); ?>" />
                <?php if($errors->has('address')): ?>
                    <?php $__currentLoopData = $errors->get('address'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <label for="cityProvince">Province / City</label>
                <select class="form-control" id="cityProvince" name="cityProvince">
                    <?php $__currentLoopData = $cty_province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cityProvince): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  value="<?php echo e($cityProvince->id); ?>"><?php echo e($cityProvince->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        
        <div class="form-group row">
            <div class="col">
                <label for="price"><?php echo e(__('hotel.Price')); ?></label>
                <input class="form-control" type="number" min="0" name="price" value="<?php echo e(old('price')); ?>" />
                <?php if($errors->has('price')): ?>
                <?php $__currentLoopData = $errors->get('price'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <strong><?php echo e($error); ?></strong>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="customFile" name="avatar" >
                    <label class="custom-file-label" for="customFile"><?php echo e(__('hotel.Choose avatar')); ?></label>
                    <?php if($errors->has('avatar')): ?>
                        <?php $__currentLoopData = $errors->get('avatar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="d-flex justify-content-end">
            
            <button class="btn btn-success" type="submit"><?php echo e(__('hotel.Init')); ?></button>
            
        </div>

</div>

</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>