<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add hotel</title>
    
</head>
<body>
    <h1>Add new hotel</h1>

    <form action="<?php echo e(route('hotel.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table>
            <tr>
                <td><label for="name">Name: </label></td>
                <td><input type="text" name="name"/></td>
            </tr>
            <tr>
                <td><label for="avg_price">Average price: </label></td>
                <td><input type="text" name="avg_price" /></td>
            </tr>
            <tr>
                <td></td>
                <td><button type="submit">Add</button></td>
            </tr>
        </table>
    </form>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>