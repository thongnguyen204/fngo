<?php $__env->startSection('dashboard'); ?>

<link href="<?php echo e(asset('css/manage.css')); ?>" rel="stylesheet">

<div style="max-width: 1300px" class="mt-3 container bg-white rounded">
    <div id="change">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col"><?php echo e(__("hotel.ID")); ?></th>
                        <th scope="col"><?php echo e(__('hotel.Product_code')); ?></th>
                        <th scope="col"><?php echo e(__('hotel.Name')); ?></th>
                        <th scope="col"><?php echo e(__('hotel.Price')); ?></th>
                        <th scope="col"><?php echo e(__('hotel.Created_at')); ?></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($hotel->id); ?></th>
                            <td><?php echo e($hotel->product_code); ?></td>
                            <td><a href="<?php echo e(route('hotel.show',$hotel)); ?>"><?php echo e($hotel->name); ?></a></td>
                            <td><?php echo e($hotel->money($hotel->price)); ?></td>
                            <td><?php echo e($hotel->created_at); ?></td>
                            <td><a class="btn btn-primary" href="<?php echo e(route('hotel.edit',[$hotel])); ?>"><i class="bi bi-pencil-fill"></i></a></td>
                            <td>
                                <button onclick="deleteHotel(<?php echo e($hotel->id); ?>)" class="btn btn-danger" type="button"><i class="bi bi-trash-fill"></i></button>    
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo e($hotels->links()); ?>

</div>
<script>

    function deleteHotel(id){
        var result = confirm("Want to delete?");
        if (result) {
            $.ajax({
            url: "deleteHotel/"+id,
            type:'delete',
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",  
            }
        }).done(function(respone){
            // console.log(respone);
            
            $("#change").empty();
            $("#change").html(respone);
        });
        }
        
    };

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>