<?php $__env->startSection('dashboard'); ?>

<link href="<?php echo e(asset('css/manage.css')); ?>" rel="stylesheet">

<div style="max-width: 1300px" class="mt-3 container bg-white rounded">
    
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session()->get('message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    
    
    <div id="change">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col"><?php echo e(__("tour.ID")); ?></th>
                        <th scope="col"><?php echo e(__('tour.Product_code')); ?></th>
                        <th scope="col"><?php echo e(__('tour.Name')); ?></th>
                        <th scope="col"><?php echo e(__('tour.Price')); ?></th>
                        <th scope="col"><?php echo e(__('tour.Created_at')); ?></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($tour->id); ?></th>
                            <td><?php echo e($tour->product_code); ?></td>
                            <td><a href="<?php echo e(route('tour.show',$tour)); ?>"><?php echo e($tour->name); ?></a></td>
                            <td><?php echo e($tour->money($tour->price)); ?></td>
                            <td><?php echo e($tour->created_at); ?></td>
                            <td><a class="btn btn-primary" href="<?php echo e(route('tour.edit',[$tour])); ?>"><i class="bi bi-pencil-fill"></i></a></td>
                            <td>
                                
                                <form action="<?php echo e(route('manage.deleteTour',$tour)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                        <button  class="btn btn-danger" type="submit"><i class="bi bi-trash-fill"></i></button>    
                                </form>
                            
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo e($tours->links()); ?>

</div>
<script>

    function deleteTour(tour_id){
        var result = confirm("Want to delete?");
        if (result) {
            $.ajax({
            url: "deleteTourAjax/"+tour_id,
            type:'delete',
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",  
            }
        }).done(function(respone){
            // console.log(respone);
            
            $("#change").empty();
            $("#change").html(respone);
        });
        }
        
    };

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>