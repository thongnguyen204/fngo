<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/hotel.css')); ?>" rel="stylesheet">
<div class="container create-form-container rounded bg-white">
    <div class="blue-bar rounded-top"></div>
    <h1 class="d-flex justify-content-center">
        <span style="padding-left: 20px;padding-right: 20px;" class="sub-title-warpper"><?php echo e(__('hotel.Edit')); ?></span>
    </h1>
<form style="padding: 20px" action="<?php echo e(route('hotel.update',$hotel)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="name"><?php echo e(__('hotel.Name')); ?></label>
        <input class="form-control" value="<?php echo e($hotel->name); ?>" type="text" name="name"/>
    </div>

    <div class="form-group">
        <label for="price"><?php echo e(__('hotel.Average price')); ?> </label>
        <input class="form-control" value="<?php echo e($hotel->price); ?>" type="number" name="price" />
    </div>

    <div class="form-group row">
        <div class="col-md-8">
            <label for="address"><?php echo e(__('hotel.Address')); ?> </label>
            <input class="form-control" value="<?php echo e($hotel->address); ?>" type="text" name="address" />
        </div>
        <div class="col-md-4">
            <label for="cityProvince"><?php echo e(__('hotel.Province/City')); ?></label>
            <select class="form-control" id="cityProvince" name="cityProvince">
                <?php $__currentLoopData = $cty_province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cityProvince): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cityProvince->id); ?>" <?php if($hotel->city_province_id == $cityProvince->id): ?>
                        selected
                    <?php endif; ?>><?php echo e($cityProvince->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="form-group ">
        <div class="custom-file">
            <input type="file" class="custom-file-input" id="customFile" name="avatar" >
            <label class="custom-file-label" for="customFile"><?php echo e(__('common.Choose avatar')); ?></label>
            <?php if($errors->has('avatar')): ?>
                <?php $__currentLoopData = $errors->get('avatar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>



        <button class="btn btn-primary" type="submit"><?php echo e(__('hotel.Update')); ?></button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>