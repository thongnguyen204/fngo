<?php $__env->startSection('content1'); ?>


<div class="wrapper ">
    <div class="container container-introduction bg-white rounded">
        <p class="content">
            <?php echo __('intro.content'); ?>

        </p>
        

        <p class="join-gif-container">
            <a href="<?php echo e(route('register')); ?>">
                <img class="join-gif rounded-circle" src="https://res.cloudinary.com/dloeyqk30/image/upload/v1635225612/FnGO/gif/join_us_nlzqvi.gif">
            </a>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>