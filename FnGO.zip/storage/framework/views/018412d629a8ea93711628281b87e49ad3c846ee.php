<?php $__env->startSection('content'); ?>

<body>
    <h1>Order room</h1>

    <form action="<?php echo e(route('HotelBooking.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="room_id" value="<?php echo e($room->id); ?>">
        <table>
            <tr>
                <td>Room number</td>
                <td><?php echo e($room->room_number); ?></td>
            </tr>
            <tr>
                <td>Type</td>
                <td><?php echo e($room->type->name); ?></td>
            </tr>
            <tr>
                <td>Room for</td>
                <td><?php echo e($room->type->max_person); ?> people(s)</td>
            <tr>
                <td>Price</td>
                <td><?php echo e($room->type->price_per_night); ?>$ per night</td>
            </tr>
            <tr>
                <td>About this room</td>
                <td id="description"><?php echo e($room->description); ?></td>
            </tr>
            <tr>
                <td>From</td>
                <td>
                    <input type="date"  name="arrive"
                        min="2021-01-01" max="2025-12-31">
                </td>
            </tr>
            <tr>
                <td>To</td>
                <td>
                    <input type="date"  name="checkout"
                        min="2021-01-01" max="2025-12-31">
                </td>
            </tr>
            <tr>
                <td></td>
                <td><button type="submit">Order this room</button></td>
            </tr>
        </table>
    </form>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>