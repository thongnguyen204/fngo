<?php $__env->startSection('content'); ?>



<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Secular+One&display=swap" rel="stylesheet">
<link href="<?php echo e(asset('css/tour.css')); ?>" rel="stylesheet">

<div style="max-width: 1300px" class="container">
    <form action="<?php echo e(route('tour.index')); ?>" method="GET">
        <div class="input-group mb-3 searchBar">
            <input placeholder="<?php echo e(__('tour.Search')); ?>" type="text" name="search" value="<?php echo e(request()->get('search')); ?>" class="form-control" placeholder="">
            <div class="input-group-append">
                <button style="width: 100px" class="btn btn-search btn-outline-secondary" type="submit"><i
                        class="bi bi-search"></i>
                </button>
            </div>
        </div>
    </form>
</div>

<div class="container rounded bg-white contain-wrapper">
    <div class="admin-button">
        <div class="row">
            <a class="btn btn-success col admin-button" href="<?php echo e(route('tour.create')); ?>"><i class="bi bi-plus-lg"></i></a>
            <a class="btn btn-primary col admin-button" href="<?php echo e(route('tour.edit',$tour)); ?>"><i class="bi bi-pencil-square"></i></a>
            <div style="padding: 0px"  class="col admin-button" >
                <form action=" <?php echo e(route('tour.destroy',$tour)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button style="width: 100%" class="btn btn-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                </form>
            </div>
        </div>
    </div>
    <h2><?php echo e($tour->name); ?></h2>
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-9">
            
            <div style="margin-bottom: 50px" class="">
                <img style="max-width: 100%;" loading="lazy" alt="tour Image" class="img_fluid rounded"
                    src="<?php echo e($tour->avatar); ?>">
            </div>
            <h3><i class="bi bi-geo-alt-fill"></i> <?php echo e(__('tour.Schedule')); ?></h3>

            <hr style="height:2px;border-width:0;color:gray;background-color:rgba(206, 144, 176, 0.5)">

            <?php $__currentLoopData = $trip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="subtrip">
                <div class="row">
                    
                    <div class="col-12 sub-title-warpper">
                        <div class="d-flex justify-content-center day-number"><?php echo e(__('common.Day')); ?> <?php echo e($subtrip->day); ?>

                        </div>
                        <h5 class="sub-title d-flex align-items-center"><?php echo e($subtrip->title); ?></h5>
                    </div>
                </div>
            </div>

            <div class="subtrip-content">
                <?php echo $subtrip->content; ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="col-12 col-sm-12 col-md-12 col-lg-3">
            <div class="make-me-sticky">
                <div class="card">
                    <div class="card-body price-button">
                        <p class="d-flex justify-content-center money"> <?php echo e($tour->money($tour->price)); ?></p>
                        <div class="d-flex justify-content-center">
                            <button onclick="addCart('<?php echo e($tour->product_code); ?>')" type="button"
                                class="btn btnAddCart btn-lg">
                                <?php echo e(__('tour.Add cart')); ?>

                            </button>
                        </div>
                    </div>
                    <div style="padding: 0px" class="card-body">
                        <div>
                            <ul class="list-group ">
                                <li class="list-group-item border-0">
                                    <i class="bi bi-calendar3"></i>&nbsp&nbsp
                                    <strong><?php echo e(__('tour.Departure date')); ?>:</strong>
                                    
                                    <?php echo e($tour->day()); ?>

                                </li>
                                <li class="list-group-item border-0">
                                    <i class="bi bi-alarm"></i>&nbsp&nbsp
                                    <strong><?php echo e(__('tour.Departure time')); ?>:</strong>
                                    <?php echo e($tour->departure_time); ?>

                                </li>
                                <li class="list-group-item border-0">
                                    <i class="bi bi-people-fill"></i>&nbsp&nbsp
                                    <strong><?php echo e(__('tour.Number of passengers')); ?>:</strong>
                                    <?php echo e($tour->passenger_num); ?>

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div style="margin-top: 20px" class="card">
                    <div class="card-body">
                        <div>
                            <div class="row">
                                <div class="col-12">
                                    <?php echo e(__('tour.Contact')); ?>

                                </div>
                                <div class="col-12">
                                    <hr
                                        style="height:1px;border-width:0;color:gray;background-color:rgba(206, 144, 176, 0.5)">
                                </div>
                                <div class="col-12">
                                    <i style="font-size: 25px" class="bi bi-whatsapp"></i>
                                    <span class="phone-number">097 5066164</span>
                                    (Mr. Trung)
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>


    function addCart(id) {
        var currentLocation = window.location;
        console.log(currentLocation);
        $.ajax({
            url: "/addCart/" + id,
            type: 'GET',

        }).done(function (respone) {
            var icon = '<span class="bi bi-bag-check test"></span>';
            alertify.notify(icon + " " + respone, 'custom');
        });

        $.ajax({
            url: "/cartQuantity",
            type: 'GET',
        }).done(function (respone) {
            $('#CartCount').text(respone);
        });

    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>