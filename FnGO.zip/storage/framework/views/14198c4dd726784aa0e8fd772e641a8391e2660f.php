<?php $__env->startSection('content'); ?>
<body>
    <div class="container">
    <h3><?php echo e(__('receipt.Receipt List')); ?></h3>
    <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="margin-top: 50px" class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-6">#<?php echo e($receipt->id); ?></div>
                <div class="col-6">
                    <?php if($receipt->status->name == 'Waiting'): ?>
                    <div style="float: right" class="btn btn-warning">
                        <?php echo e(__('receipt.Waiting')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($receipt->status->name == 'Accepted'): ?>
                    <div style="float: right" class="btn btn-primary">
                        <?php echo e(__('receipt.Accepted')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($receipt->status->name == 'Canceled'): ?>
                    <div style="float: right" class="btn btn-secondary">
                        <?php echo e(__('receipt.Canceled')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($receipt->status->name == 'Payment received'): ?>
                    <div style="float: right" class="btn btn-success">
                        <?php echo e(__('receipt.Received')); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <?php echo e($receipt->created_at); ?>

                </div>
            </div>
        </div>
        <div class="">
            <?php $__currentLoopData = $receipt->receipt_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body border">
                    
                    <div class="row">
                        <div class="col-12 col-md-2">
                            <img class="img-thumbnail"  style="max-width: 100%;" loading="lazy" alt="hotek Image" class="img_fluid"
                            src="<?php echo e($detail->product->avatar); ?>">
                        </div>
                        <div class="col-12 col-md-10">
                            <div class="row">
                                <div class="col-12"> 
                                    <?php echo e($detail->product->name); ?>

                                </div>
                                <div class="col-12"> 
                                    x <?php echo e($detail->quantity); ?>

                                </div>
                                <div class="col-12"> 
                                    <?php echo e($detail->description); ?>

                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="card-footer">
            <div style="float: right;" class="row">
                <div  class="col-12">
                    <?php echo e(__('receipt.Total')); ?>: <?php echo e(($receipt->money($receipt->price_sum))); ?>

                        
                </div>
            </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>