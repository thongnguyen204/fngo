<?php $__env->startSection('content'); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans&display=swap" rel="stylesheet">
<link href="<?php echo e(asset('css/article.css')); ?>" rel="stylesheet">

<div>
    <?php echo $__env->make('layouts.onlySearchBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div class="container">


</div>
<div class="container rounded bg-white wrapper">
    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->role->name != 'user'): ?>
            <a class="btn btn-success col mb-3" href="<?php echo e(route('article.create')); ?>"><i class="bi bi-plus-lg"></i></a>
        <?php endif; ?>
    <?php endif; ?>
    
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="article-wrapper">
        <div class="row d-flex align-items-center">
            <div class="col-12 col-sm-2 d-flex align-items-center justify-content-center">

                <a class="d-block d-sm-none" style="max-height: 200px;width: 100%;" href="<?php echo e(route('article.show',$article)); ?>">
                    <img style="max-height: 200px" class="img_fliud thumbnail rounded" src="<?php echo e($article->thumbnail); ?>">
                </a>

                <a class=" d-none d-sm-block" style="max-height: 200px;" href="<?php echo e(route('article.show',$article)); ?>">
                    <img style="max-height: 150px" class="img_fliud thumbnail rounded-circle" src="<?php echo e($article->thumbnail); ?>">
                </a>

            </div>
            <div class="col-12 col-sm-10">
                <div class="row">
                    <div class="title col">
                        <a href="<?php echo e(route('article.show',$article)); ?>">
                        <?php echo e($article->title); ?>

                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col info">
                        <i class="bi bi-person-fill"></i>
                        <span style="margin-right: 10px;" class="author"><?php echo e($article->user->name); ?></span>
                        <i class="bi bi-clock"></i> 
                        
                        <span class="publish-date"><?php echo e($article->created_at); ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col abstract">
                        <?php echo e($article->abstract); ?>

                    </div>
                </div>
                <div class="row d-none d-sm-block">
                    <div class="col">
                        <div class="">
                            <a href="<?php echo e(route('article.show',$article)); ?>" type="button" class="btn btn-readmore">
                                <?php echo e(__('article.Read more')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($articles->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>