<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/post.css')); ?>" rel="stylesheet">

<div style="max-width: 1100px;" class="container rounded bg-white wrapper">
    <div class="post-wrapper">
        <div class="row">
            <div class="col-3">
                <img class="img_fliud thumbnail" src="https://res.cloudinary.com/dloeyqk30/image/upload/v1633314428/FnGO/hotelImage/roomType/2_double_bed_zv5hjp.jpg">
            </div>
            <div class="col-9">
                <div class="row">
                    <div class="title col">
                        HANGING OUT WITH OLD FRIENDS.
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <i class="bi bi-person-fill"></i>
                        <span class="author">dialga</span>
                        <i class="bi bi-clock"></i>
                        <span class="publish-date">20/04/2000</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>