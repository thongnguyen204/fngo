<?php $__env->startSection('dashboard'); ?>

<link href="<?php echo e(asset('css/receipt.css')); ?>" rel="stylesheet">

<div class="container bg-white rounded wrapper">
    <?php echo $__env->make('admin.receiptAccepted.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col"><?php echo e(__('receipt.User')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Cost')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Status')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Finish')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Payment')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Order date')); ?></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><a href="<?php echo e(route('receipt.show',$receipt)); ?>"><?php echo e($receipt->id); ?></a></th>
                <td><?php echo e($receipt->user->name); ?></td>
                <td><?php echo e($receipt->money($receipt->price_sum)); ?></td>
                
                
                <td>
                    <?php switch($receipt->payment_id ):
                        case (1): ?>
                            <?php echo e(__('receipt.Accepted')); ?>

                            <?php break; ?>
                        <?php case (2): ?>
                            <?php echo e(__('receipt.Canceled')); ?>

                            <?php break; ?>
                        <?php case (3): ?>
                            <?php echo e(__('receipt.Waiting')); ?>

                            <?php break; ?>
                        <?php case (4): ?>
                            <?php echo e(__('receipt.Paid')); ?>

                            <?php break; ?>
                        <?php case (5): ?>
                            <?php echo e(__('receipt.Momo waiting')); ?>

                            <?php break; ?>
                        <?php case (6): ?>
                            <?php echo e(__('receipt.Momo Canceled')); ?>

                            <?php break; ?>
                        <?php default: ?>
                        <?php echo e(__('receipt.Else')); ?>

                    <?php endswitch; ?>
                </td>
                <td>
                    <?php if($receipt->is_finish): ?>
                    <i style="font-size: 30px;color:#1FAA59" class="bi bi-check-circle-fill"></i>
                    <?php else: ?>
                    <i style="font-size: 30px;color:#DE4839" class="bi bi-x-circle-fill"></i>
                    <?php endif; ?>
                </td>
                
                <td>
                    <?php if($receipt->payment_id == 1): ?>
                        <?php echo e(__('receipt.Offline')); ?>

                    <?php else: ?>
                        <?php if($receipt->payment_id == 2): ?>
                            <?php echo e(__('receipt.Banking')); ?>

                        <?php else: ?>
                            <?php if($receipt->payment_id == 3): ?>
                                <?php echo e(__('receipt.PayPal')); ?>

                            <?php else: ?>
                                <?php if($receipt->payment_id == 4): ?>
                                    <?php echo e(__('receipt.Momo')); ?>

                                <?php else: ?>
                                    <?php echo e(__('receipt.Else')); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    

                </td>
                <td><?php echo e($receipt->created_at); ?></td>
                <td class="row">
                    <?php if($receipt->status_id == 4): ?>
                    <a style="margin: 10px" class="btn btn-success col" href="<?php echo e(route('receipt.unpay',$receipt->id)); ?>"><?php echo e(__('receipt.Unpay')); ?></a>
                    <?php else: ?>
                    <a style="margin: 10px" class="btn btn-success col" href="<?php echo e(route('receipt.pay',$receipt->id)); ?>"><?php echo e(__('receipt.Paid')); ?></a>
                    <?php endif; ?>
                    <a style="margin: 10px" class="btn btn-secondary col" href="<?php echo e(route('receipt.cancel',$receipt->id)); ?>">
                        <div class="d-flex align-items-center justify-content-center" style="height: 100%"><?php echo e(__('receipt.Cancel')); ?></div>
                    </a>
                </td>
                <td>
                    <?php if($receipt->is_finish): ?>
                        <a style="margin: 10px" class="btn btn-success col" href="<?php echo e(route('receipt.un-finish',$receipt)); ?>">
                            <?php echo e(__('receipt.Not finish')); ?>

                        </a>
                    <?php else: ?>
                        <a style="margin: 10px" class="btn btn-success col" href="<?php echo e(route('receipt.finish',$receipt)); ?>">
                            <?php echo e(__('receipt.Finish')); ?>

                        </a>
                    <?php endif; ?>
                    
                </td>
                <td>
                    <form action="<?php echo e(route('receipt.destroy',$receipt)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <?php echo e($receipts->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>