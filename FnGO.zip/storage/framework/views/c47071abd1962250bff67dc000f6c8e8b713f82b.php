

<?php $__env->startSection('content'); ?>
<link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
<link href="<?php echo e(asset('css/home.css')); ?>"  rel="stylesheet">
<link href="<?php echo e(asset('css/tour.css')); ?>"  rel="stylesheet">
<link href="<?php echo e(asset('css/hotel.css')); ?>" rel="stylesheet">
    
</head>
<body>
    <div class="slide">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img style="max-height: 500px" class="d-block w-100" src="https://res.cloudinary.com/dloeyqk30/image/upload/v1634910928/FnGO/home-banner/tokyo-banner_s4ydsk.jpg" alt="First slide">
              </div>
              <div class="carousel-item">
                <img style="max-height: 500px" class="d-block w-100" src="https://res.cloudinary.com/dloeyqk30/image/upload/v1634911384/FnGO/home-banner/tokyo-banner1_ofhswb.jpg" alt="Second slide">
              </div>
              <div class="carousel-item">
                <img style="max-height: 500px" class="d-block w-100" src="https://res.cloudinary.com/dloeyqk30/image/upload/v1634910928/FnGO/home-banner/tokyo-banner_s4ydsk.jpg" alt="Third slide">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
    </div>
    <div>
      <?php echo $__env->make('layouts.onlySearchBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div style="max-width: 1300px" class="container">
        <div class="title-top rounded">
          <i class="bi bi-camera-fill"></i>
          <?php echo e(__('home.top tour')); ?>

        </div>
        <div class="card-group">
          <div class="row ">
            <?php $__currentLoopData = $topTour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="card col-6 col-sm-4 col-md-3">
                  <div style="padding: 10px" class="card-img-top">
                      <a href="<?php echo e(route('tour.show',$trip)); ?>">
                          <img loading="lazy" alt="tour Image" class="img-fluid rounded pictrure" src="<?php echo e($trip->avatar); ?>">
                      </a>
                  </div>
                  <div class="card-body tour-info">
                      <div class="row row-name">
                          <a class="link" href="<?php echo e(route('tour.show',$trip)); ?>">
                              <div  class="col-md-12 tour-name"><?php echo e($trip->name); ?></div>
                          </a>
                      </div>
      
                      
                  </div>
                  <div class="card-footer">
                    <div id="money" class="float-right" style="width: 130px"><?php echo e($trip->money($trip->price)); ?></div>
                  </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="more-btn-wrapper d-flex justify-content-center">
        <a class="btn" href="<?php echo e(route('tour.index')); ?>">
          <?php echo e(__('home.More')); ?>

          <i style="margin-left: 5px" class="bi bi-arrow-right"></i>
        </a>
      </div>
    </div>
    <div style="max-width: 1300px"  class="container">

      <div class="title-top rounded">
        <i class="bi bi-house-door-fill"></i> 
        <?php echo e(__('home.top hotel')); ?>

      </div>

      <div class="card-group">
        <div class="row">
          <?php $__currentLoopData = $topHotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card col-6 col-sm-4 col-md-3">
              <div style="padding: 10px" class="card-img-top">
                  <a  href="<?php echo e(route('hotel.show',$hotel)); ?>">
                      <img loading="lazy" alt="hotel Image" class="img_fluid rounded pictrure"
                          src="<?php echo e($hotel->avatar); ?>">
                  </a>
              </div>
              <div class="card-body hotel-info">
                  <div class="row row-name">
                      <a class="link" href="<?php echo e(route('hotel.show',$hotel)); ?>">
                          <div class="col-md-12 tour-name hotel-name-index"><?php echo e($hotel->name); ?></div>
                      </a>
                  </div>
              </div>
              <div class="card-footer">
                <div id="money" class="float-right" style="width: 130px"><?php echo e($hotel->money($hotel->price)); ?></div>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

      <div class="more-btn-wrapper d-flex justify-content-center">
        <a class="btn" href="<?php echo e(route('hotel.index')); ?>">
          <?php echo e(__('home.More')); ?>

          <i style="margin-left: 5px" class="bi bi-arrow-right"></i>
        </a>
      </div>

    </div>

    <div style="max-width: 1300px"  class="container">
      <div class="title-top rounded">
        <i class="bi bi-newspaper"></i>
        <?php echo e(__('home.top article')); ?>

      </div>
      <div class="card-group">
        <div class="row">
          <?php $__currentLoopData = $topArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card col-6 col-sm-4 col-md-3">
              <div style="padding: 10px" class="card-img-top">
                <a href="<?php echo e(route('article.show',$article)); ?>">
                    <img loading="lazy" alt="article Image" class="img_fluid rounded pictrure"
                        src="<?php echo e($article->thumbnail); ?>">
                </a>
              </div>
              <div class="card-body">
                <a  class="link" href="<?php echo e(route('article.show',$article)); ?>">
                  <div class="card-title article-title"><?php echo e($article->title); ?></div>
                </a>
                <p class="card-text"><?php echo e($article->abstract); ?></p>
                
              </div>

            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="more-btn-wrapper d-flex justify-content-center">
        <a class="btn" href="<?php echo e(route('article.index')); ?>">
          <?php echo e(__('home.More')); ?>

          <i style="margin-left: 5px" class="bi bi-arrow-right"></i>
        </a>
      </div>
    </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>