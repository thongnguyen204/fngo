<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/article.css')); ?>" rel="stylesheet">


<div class="container create-form-container rounded bg-white">
    <div class="green-bar rounded-top"></div>
        
    <h1 class="d-flex justify-content-center">
        <span style="padding-left: 20px;padding-right: 20px;" class="sub-title-warpper"><?php echo e(__('article.Create')); ?></span>
    </h1>
    <form style="padding: 20px" action="<?php echo e(route('article.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="formType" name="formType" value="create">
        <div class="form-group row">
            <div class="col">
                <label for="title"><?php echo e(__('article.Title')); ?></label>
                <input class="form-control" type="text" name="title" value="<?php echo e(old('title')); ?>" />
                <?php if($errors->has('title')): ?>
                    <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col">
                <label for="abstract"><?php echo e(__('article.Abstract')); ?></label>
                <input class="form-control" type="text" name="abstract" value="<?php echo e(old('abstract')); ?>" />
                <?php if($errors->has('abstract')): ?>
                    <?php $__currentLoopData = $errors->get('abstract'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="customFile" name="thumbnail" >
                    <label class="custom-file-label" for="customFile"><?php echo e(__('article.Choose thumbnail')); ?></label>
                    <?php if($errors->has('thumbnail')): ?>
                        <?php $__currentLoopData = $errors->get('thumbnail'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <div class="col">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="background" name="background" >
                    <label class="custom-file-label" for="background"><?php echo e(__('article.Choose background')); ?></label>
                    <?php if($errors->has('background')): ?>
                        <?php $__currentLoopData = $errors->get('background'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <div class="col">
                <label for="content"><?php echo e(__('article.Content')); ?></label>
                <textarea name="content" id="ckeditor"></textarea>
                <?php if($errors->has('price')): ?>
                <?php $__currentLoopData = $errors->get('price'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <strong><?php echo e($error); ?></strong>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="d-flex justify-content-end">
            
            <button class="btn btn-success" type="submit"><?php echo e(__('article.Create')); ?></button>
            
        </div>
    </form>
</div>
<script src="//cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('ckeditor');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>