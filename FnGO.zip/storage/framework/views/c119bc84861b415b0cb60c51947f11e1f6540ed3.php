<div class="d-flex justify-content-center row">
    <div style="width: 100%" class="coment-bottom bg-white">
        <?php if(auth()->guard()->check()): ?>
        <div class="input-comment d-flex flex-row add-comment-section mt-4 mb-4">
            <img class="img-fluid img-responsive rounded-circle mr-2" src="<?php echo e(Auth::user()->avatar); ?>" width="38">
            <input id="comment" data-product="<?php echo e($product_code); ?>" type="text" class="form-control mr-3" placeholder="Add comment">
            <button onclick="addComment('<?php echo e($product_code); ?>')" class="btn btn-primary" type="button">Comment</button>
        </div>
        <?php endif; ?>

        <?php echo $__env->make('comment.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    </div>
</div>