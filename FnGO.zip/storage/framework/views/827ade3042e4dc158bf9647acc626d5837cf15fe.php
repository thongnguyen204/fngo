<?php $__env->startSection('content'); ?>
<h1>Admin panel</h1>



<div>
    <a href='<?php echo e(route('users.index')); ?>'>Users manage</a>
</div>

<div>
    <a href='<?php echo e(route('hotel.index')); ?>'>Hotels manage</a>
</div>

<div>
    <a href='<?php echo e(route('tour.index')); ?>'>Tours</a>
</div>

<div>
    <a href='<?php echo e(route('receipt.index')); ?>'>Receipts queue</a>
</div>

<div>
    <a href='<?php echo e(route('receipt.indexAccepted')); ?>'>Receipts manage</a>
</div>

<img src="<?php echo e(URL::to('/img/eli.jpg')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>