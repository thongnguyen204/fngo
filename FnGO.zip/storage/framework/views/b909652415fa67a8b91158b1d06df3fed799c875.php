<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FnGO</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
    <!-- Default theme -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css"/>
    <!-- Semantic UI theme -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/semantic.min.css"/>
    <!-- Bootstrap theme -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>
    
</head>
<body>
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
        <div  class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <?php echo e(config('app.name', 'Laravel')); ?>

            </a>
            <div id="menu">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('hotel.index')); ?>"><?php echo e(__('welcome.Hotels')); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('tour.index')); ?>"><?php echo e(__('welcome.Tours')); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('article.index')); ?>"><?php echo e(__('welcome.Articles')); ?></a>
                  </li>
                </ul>
            </div>
              
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>
            

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                
                <ul class="navbar-nav ml-auto">
                    <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link"
                               href="<?php echo e(route('language',$locale)); ?>"
                                <?php if(app()->getLocale() == $locale): ?> style="font-weight: bold; text-decoration: underline" <?php endif; ?>><?php echo e(strtoupper($locale)); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('welcome.Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('welcome.Register')); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <i style="font-size: 25px" class="bi bi-person-circle"></i> <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu " aria-labelledby="navbarDropdown">
                                <?php if(Auth::user()->role->name == 'admin'): ?>
                                    <a class="dropdown-item" href="<?php echo e(url('/dashboard')); ?>">
                                        <?php echo e(__('common.Admin dashboard')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if(Auth::user()->role->name == 'employee'): ?>
                                    <a class="dropdown-item" href="<?php echo e(url('/receiptWaiting')); ?>">
                                        <?php echo e(__('common.Manage')); ?>

                                    </a>
                                <?php endif; ?>
                                

                                <a class="dropdown-item" href="<?php echo e(route('users.edit', Auth::user())); ?> ">
                                    <?php echo e(__('common.Account settings')); ?>

                                </a>

                                <?php if(Auth::user()->role->name != 'admin'): ?>
                                    <a class="dropdown-item" href="<?php echo e(url('/receipt')); ?>">
                                        <?php echo e(__('common.Receipt')); ?>

                                    </a>
                                <?php endif; ?>

                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('common.Logout')); ?>

                                </a>
                                
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                            <li class="nav-item cartIcon">
                                <form action="<?php echo e(route('cart.index')); ?>" method="GET">
                                    <button type="submit" class="btn">
                                        <i style="color:white;font-size: 25px" class="bi bi-cart"></i>
                                        <?php if(Session::get('Cart') != null): ?>
                                            <span class='badge badge-warning' id='CartCount'> <?php echo e(Session::get('Cart')->quantity); ?> </span>
                                        <?php else: ?>
                                            <span class='badge badge-warning' id='CartCount'> 0 </span>
                                        <?php endif; ?>
                                        
                                    </button>
                                </form>
                            </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <main style="min-height: 800px">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

<script src="<?php echo e(asset('js/script.js')); ?>" defer></script>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>



<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>


<script src="//cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>

<script>
    // CKEDITOR.replace('ckeditor');
</script>
</html>