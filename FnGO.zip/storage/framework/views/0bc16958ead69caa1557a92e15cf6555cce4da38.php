<?php $__env->startSection('content'); ?>

<body>
    <h1>Create room</h1>
    <form action="<?php echo e(route('room.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table>
            <tr>
                <td><label for="room_number">Room number: </label></td>
                <td><input type="text" name="room_number" 
                    /></td>
            </tr>
            <tr>
                <td><label for="hotel_id">Hotel: </label></td>
                <td>
                    <?php echo e($room->hotel->name); ?>

                    <input type="hidden" name="hotel_id" 
                    value="<?php echo e($room->hotel_id); ?>"
                    />
                </td>
            </tr>
            <tr>
                <td><label for="type_id">Type: </label></td>
                <td>
                    <select name="type_id" size="1">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                </td>
            </tr>
            <tr>
                <td><label for="description">Description: </label></td>
                
                    <td>
                        <textarea cols="30" rows="8" name="description" 
                        ></textarea>
                    </td>
            </tr>
            <tr>
                <td></td>
                <td><button type="submit">Add</button></td>
            </tr>
        </table>
    </form>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>