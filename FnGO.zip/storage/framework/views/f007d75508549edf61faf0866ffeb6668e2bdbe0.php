<?php $__env->startSection('content'); ?>


<body>
    <h1>Edit room</h1>
    <form action="<?php echo e(route('room.update',$room->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <table>
            <tr>
                <td><label for="room_number">Room number: </label></td>
                <td><input type="text" name="room_number" 
                    value="<?php echo e($room->room_number); ?>"/></td>
            </tr>
            <tr>
                <td><label for="hotel_id">Hotel: </label></td>
                <td>
                    <select name="hotel_id" size="1">
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($hotel->id == $room->hotel->id): ?>
                            <option value="<?php echo e($hotel->id); ?>" selected><?php echo e($hotel->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($hotel->id); ?>"><?php echo e($hotel->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                </td> 
            </tr>
            <tr>
                <td><label for="type">Type: </label></td>
                <td>
                    <select name="type_id" size="1">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($type->name == $room->type->name): ?>
                            <option value="<?php echo e($type->id); ?>" selected><?php echo e($type->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                </td>
            </tr>
            <tr>
                <td><label for="available">Available: </label></td>
                <td>
                    <select name="available" size="1">
                        <option value="1" <?php if($room->available == 1): ?>
                            <?php echo e("Selected"); ?>

                        <?php endif; ?>>Yes</option>
                        <option value="0" <?php if($room->available == 0): ?>
                            <?php echo e("Selected"); ?>

                        <?php endif; ?>>No</option>
                      </select>
                </td>
            </tr>
            <tr>
                <td><label for="description">Description: </label></td>
                    <td>
                        <textarea cols="30" rows="8" name="description" 
                        value="<?php echo e($room->description); ?>"><?php echo e($room->description); ?></textarea>
                    </td>
            </tr>
            <tr>
                <td></td>
                <td><button type="submit">Update</button></td>
            </tr>
        </table>
    </form>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>