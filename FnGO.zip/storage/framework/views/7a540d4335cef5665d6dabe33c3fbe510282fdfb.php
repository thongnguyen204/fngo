<?php $__env->startSection('content'); ?>


<div class="container">
    <h1>Receipt Detail</h1>
    
    <div class="table-responsive">
    <table class="table ">
    <thead>
        <tr>
            <th scope="col">Receipt ID</th>
            <th scope="col">Product</th>
            <th scope="col">Price</th>
            <th scope="col">Quantity</th>
            
            
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $receiptDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiptDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th scope="row"><?php echo e($receiptDetail->receipt_id); ?></th scope="row">
        <td>
            <a href="<?php echo e(route('product.show',$receiptDetail->product_code)); ?>" ><?php echo e($receiptDetail->product->name); ?> </a>
        </td>
        <td><?php echo e($receiptDetail->price); ?></td>
        <td><?php echo e($receiptDetail->quantity); ?></td>

        
        
        <td><?php echo e($receiptDetail->description); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    </div>
    <?php echo e($receiptDetails->links()); ?>

    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>