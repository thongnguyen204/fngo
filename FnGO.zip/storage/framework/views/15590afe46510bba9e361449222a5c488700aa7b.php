<?php $__env->startSection('dashboard'); ?>

<link href="<?php echo e(asset('css/receipt.css')); ?>" rel="stylesheet">

<div class="container bg-white rounded wrapper">
    <form style="margin-bottom: 20px" action="<?php echo e(route('receipt.search')); ?>" method="GET">
        <div style="margin-bottom: 0px" class="input-group searchBar">
            <input placeholder="<?php echo e(__('receipt.Search')); ?>" type="text" name="search" value="<?php echo e(request()->get('search')); ?>" class="form-control" placeholder="">
            <div class="input-group-append">
                <button style="width: 100px" class="btn btn-search btn-outline-secondary" type="submit"><i
                        class="bi bi-search"></i>
                </button>
            </div>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="searchOptions" id="inlineRadio1" value="id">
            <label class="form-check-label" for="inlineRadio1">ID</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="searchOptions" id="inlineRadio2" value="userid">
            <label class="form-check-label" for="inlineRadio2"><?php echo e(__("receipt.User's ID")); ?></label>
        </div>
        
    </form>
    <?php if(!$receipts): ?>
        <?php echo e(__('receipt.Empty')); ?>

    <?php else: ?>
    <div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col"><?php echo e(__('receipt.User')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Cost')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Status')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Payment')); ?></th>
                <th scope="col"><?php echo e(__('receipt.Order date')); ?></th>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><a href="<?php echo e(route('receipt.show',$receipt)); ?>"><?php echo e($receipt->id); ?></a></th>
                <td><?php echo e($receipt->user->name); ?></td>
                <td><?php echo e($receipt->money($receipt->price_sum)); ?></td>
                
                
                <td>
                    <?php if($receipt->status_id == 1): ?>
                        <?php echo e(__('receipt.Accepted')); ?>

                    <?php else: ?>
                        <?php if($receipt->status_id == 2): ?>
                            <?php echo e(__('receipt.Canceled')); ?>

                        <?php else: ?>
                            <?php if($receipt->status_id == 3): ?>
                                <?php echo e(__('receipt.Waiting')); ?>

                            <?php else: ?>
                                <?php echo e(__('receipt.Received')); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                
                <td>
                    <?php if($receipt->payment_id == 1): ?>
                        <?php echo e(__('receipt.Offline')); ?>

                    <?php else: ?>
                        <?php echo e(__('receipt.Banking')); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($receipt->created_at); ?></td>
                <td class="row">
                    <?php if($receipt->status_id == 4): ?>
                    <a style="margin: 10px" class="btn btn-success col" href="<?php echo e(route('receipt.unpay',$receipt->id)); ?>">Unpay</a>
                    <?php else: ?>
                    <a style="margin: 10px" class="btn btn-success col" href="<?php echo e(route('receipt.pay',$receipt->id)); ?>">Paid</a>
                    <?php endif; ?>
                    
                    <a style="margin: 10px" class="btn btn-secondary col" href="<?php echo e(route('receipt.cancel',$receipt->id)); ?>">Cancel</a>
                </td>
                <td>
                    <form action="<?php echo e(route('receipt.destroy',$receipt)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>