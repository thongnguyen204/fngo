
<?php if($product_code[0] == 't'): ?>
<div style="margin-top: 20px;" class="container rounded bg-white contain-wrapper">
    <?php else: ?>
        <?php if($product_code[0] == 'h'): ?>
        <div style="max-width: 1300px;margin-top: 20px;padding: 20px;" class="container rounded bg-white">
        <?php endif; ?>
    <?php endif; ?>

    <?php echo $__env->make('comment.layout.change', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
