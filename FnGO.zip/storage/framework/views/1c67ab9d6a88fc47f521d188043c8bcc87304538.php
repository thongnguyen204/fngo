<?php $__env->startSection('content'); ?>


<?php if(Session::has('Cart') != null): ?>

<link href="<?php echo e(asset('css/cart.css')); ?>" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">

<style>
    .ajs-message.ajs-custom {
        color: #ffffff;
        /* background-color: #d9edf7;   */
        background: rgba(91, 189, 114, 0.95);
        border-color: #31708f;
    }
</style>

<div class="mt-4 container bg-white rounded padding-bottom-3x mb-1">
    <!-- Alert-->
    <?php if(session()->has('error')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong><?php echo e(__('payment.Fail')); ?></strong><?php echo e(__('payment.CheckMomo')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
    
    <!-- Shopping Cart-->
    <div id="change">
        <div class="table-responsive shopping-cart">
            <table class="table">
                <thead>
                    <tr>
                        
                        <th></th>
                        <th class="text-center"><?php echo e(__('cart.Quantity')); ?></th>
                        <th class="text-center"><?php echo e(__('cart.Price')); ?></th>

                        <th class="text-center">
                            <a class="btn btn-sm btn-outline-danger" href="<?php echo e(route('clearCart')); ?>"><?php echo e(__('cart.Clear Cart')); ?></a>
                        </th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = Session::get('Cart')->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="product-item">
                                <?php if($product['productInfo']->product_code[0] == 't'): ?>
                                <a class="product-thumb" href="<?php echo e(route('tour.show',$product['productInfo']->id)); ?>"><img style="width: 200px; height: 160px"
                                        src="<?php echo e($product['productInfo']->avatar); ?>" alt="Product"></a>
                                <div class="product-info">
                                    <h4 class="product-title"><a href="<?php echo e(route('tour.show',$product['productInfo']->id)); ?>"><?php echo e($product['productInfo']->name); ?></a></h4>
                                <?php else: ?>
                                <a class="product-thumb" href="<?php echo e(route('hotel.show',$product['productInfo']->id)); ?>"><img style="width: 200px; height: 160px"
                                    src="<?php echo e($product['productInfo']->avatar); ?>" alt="Product"></a>
                            <div class="product-info">
                                <h4 class="product-title"><a href="<?php echo e(route('hotel.show',$product['productInfo']->id)); ?>"><?php echo e($product['productInfo']->name); ?></a></h4>
                                <?php endif; ?>

                                    <div>
                                        <?php if($product['productInfo']->product_code[0] == 'h'): ?>
                                        <div>
                                            <?php echo e($product['productInfo']->day); ?> night(s)
                                            <?php echo e($product['productInfo']->date); ?>

                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        
                        <td class="text-center">
                            
                            <div class="quantity">
                                <span class="pro-qty">
                                    <?php if($product['productInfo']->product_code[0] == 't'): ?>
                                    <input disabled data-price="<?php echo e($product['price']); ?>" data-day="1" data-date="" data-id="<?php echo e($product['productInfo']->product_code); ?>" id="product-<?php echo e($product['productInfo']->product_code); ?>" type="text" value="<?php echo e($product['quantity']); ?>">
                                    <?php else: ?>
                                    <input disabled data-price="<?php echo e($product['price']); ?>" data-day="<?php echo e($product['productInfo']->day); ?>" data-date="<?php echo e($product['productInfo']->checkin_date); ?>" data-id="<?php echo e($product['productInfo']->product_code); ?>" id="product-<?php echo e($product['productInfo']->product_code); ?>" type="text" value="<?php echo e($product['quantity']); ?>">
                                    <?php endif; ?>
                                </span>
                            </div>
                        </td>

                        <td class="text-center text-lg text-medium"><?php echo e(Session::get('Cart')->money($product['price'])); ?></td>
                        <!-- <?php echo e(Session::get('Cart')->money($product['price'])); ?> -->
                        <td class="text-center">
                            <a class="remove-from-cart" href="#!" data-toggle="tooltip" title=""
                                data-original-title="Remove item">
                                <div class="remove">
                                    <i class=" fa fa-trash" data-id="<?php echo e($product['productInfo']->product_code); ?>"></i>
                                </div>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <div class="shopping-cart-footer">
            <div class="column">
                
            </div>
            <div class="column text-lg"><?php echo e(__('cart.Total')); ?>: 
                <span class="text-medium"><?php echo e(Session::get('Cart')->money(Session::get('Cart')->totalPrice)); ?></span>
                
                <input id="totalUSD" type="hidden" value="<?php echo e(Session::get('Cart')->VNDtoUSD(Session::get('Cart')->totalPrice)); ?>">
            </div>
        </div>

        

        <div class="shopping-cart-footer">
            <div class="column">
                
                <div class="form-check">
                    <input class="form-check-input" value="1" type="radio" name="payment" id="flexRadioDefault1" checked>
                    <label class="form-check-label" for="flexRadioDefault1">
                      <?php echo e(__('cart.Cash')); ?>

                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" value="2" type="radio" name="payment" id="flexRadioDefault2">
                    <label class="form-check-label" for="flexRadioDefault2">
                        <?php echo e(__('cart.Banking')); ?>

                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" value="4" type="radio" name="payment" id="flexRadioDefault3">
                    <label class="form-check-label" for="flexRadioDefault3">
                        <?php echo e(__('cart.Momo')); ?>

                    </label>
                </div>
                
                
            </div>
            <div class="column">
                <a class="update btn btn-primary" href="#!" data-toast="" data-toast-type="success" data-toast-position="topRight"
                    data-toast-icon="icon-circle-check" data-toast-title="Your cart"
                    data-toast-message="is updated successfully!">
                    <?php echo e(__('cart.Update Cart')); ?>

                </a>
                
                <a class="checkout btn btn-success" href="#!"><?php echo e(__('cart.Checkout')); ?></a>
                
            </div>
        </div>
        <div class="shopping-cart-footer">
            <div class="column">
                <?php echo e(__('cart.paypal')); ?>

            </div>
            <div class="column">
                <div id="paypal-button"></div>

            </div>
        </div>
    </div>
    
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('js/cart.js')); ?>" defer></script>
<script>
    function updateCart(){
        var list= [];
        $("table tbody tr td").each(function(){
            $(this).find("input").each(function(){
                var element = {key: $(this).data("id"),value: $(this).val()};
                list.push(element);
            });
        });

        console.log(list);
        var list1 = [1,2,3]
        $.ajax({
            url: "updateCart",
            type:'POST',
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",
                "data": list,
            }
        }).done(function(respone){
            var icon = '<span class="bi bi-bag-dash"></span>';
            $("#change").empty();
            $("#change").html(respone);
            var noti = $( "#noti" ).val();
            // alertify.notify(icon+ " " + noti, 'custom');
        });
        $.ajax({
            url: "cartQuantity" ,
            type:'GET',   
        }).done(function(respone){
            $('#CartCount').text(respone);
            
        });
    }

    $("#change").on("click", ".remove i", function () {
        
        $.ajax({
            url: '/deleteCart/' + $(this).data('id'),
            type: 'GET',
        }).done(function (respone) {
            var icon = '<span class="bi bi-bag-dash"></span>';
            $("#change").empty();
            $("#change").html(respone);
            var noti = $( "#noti" ).val();
            alertify.notify(icon+ " " + noti, 'custom');
        });

        $.ajax({
            url: "cartQuantity" ,
            type:'GET',   
        }).done(function(respone){
            $('#CartCount').text(respone);
            
        });
    });

    
    // so luong tung mon trong gio hang
    

    $(".update").on("click",function(){
        updateCart();
        
    });

    function checkout(payment){
        // updateCart();
        var list= [];
        
        $("table tbody tr td").each(function(){
            $(this).find("input").each(function(){
                var element = {key: $(this).data("id"),value: $(this).val(),day: $(this).data("day"),price: $(this).data("price"),date: $(this).data("date")};
                list.push(element);
            });
        });
        // var list1 = [1,2,3];
        console.log(list);
        $.ajax({
            url: "booking",
            type:'POST',
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",
                "data": list,
                "payment": payment,
            }
        }).done(function(respone){
            // console.log(respone);
            if(payment == 4)
            {
                if(respone == 'error')
                    {
                        
                        alertify.error('Error');
                    }
                else
                    
                    location.href = respone;
                    // console.log(respone);
            }
            else
                {
                    location.href = '/receipt';
                }
        });
    }


    $(".checkout").on("click",function(){
        var payment =$('input[name="payment"]:checked').val();

        checkout(payment);
    });

    

</script>

<script src="https://www.paypalobjects.com/api/checkout.js"></script>
<script>

    var usd = $( "#totalUSD" ).val();
  paypal.Button.render({
    
    // Configure environment
    env: 'sandbox',
    client: {
      sandbox: 'ARXQy4nMUiXnq6zEB8oVvv5a2THNl-4W9lJp4HNgIqmOcv1HxC9XUpdlnqstsUuPiSgES9hbJcGnLONt',
      production: 'demo_production_client_id'
    },
    // Customize button (optional)
    locale: 'en_US',
    style: {
      size: 'medium',
      color: 'gold',
      shape: 'pill',
    },
    
    // Enable Pay Now checkout flow (optional)
    commit: true,
    
    // Set up a payment
    
    payment: function(data, actions) {
      return actions.payment.create({
        transactions: [{
          amount: {
            total: usd,
            currency: 'USD'
          }
        }]
      });
    },
    // Execute the payment
    onAuthorize: function(data, actions) {
      return actions.payment.execute().then(function() {
        // Show a confirmation message to the buyer
        // 3 is paypal
        console.log(data);
        // var payment = 3;
        // checkout(payment);
      });
    }
  }, '#paypal-button');

</script>





<?php else: ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body cart">
                    <div class="col-sm-12 empty-cart-cls text-center"> <img src="https://i.imgur.com/dCdflKN.png" width="130" height="130" class="img-fluid mb-4 mr-3">
                        <h3><strong><?php echo e(__('cart.Empty')); ?></strong></h3>
                        <h4><?php echo e(__('cart.Add something')); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>