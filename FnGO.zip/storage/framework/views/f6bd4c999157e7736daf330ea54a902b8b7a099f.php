<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('receipt.update',$receipt->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <table>
        <tr>
            <td>User </td>
            <td><?php echo e($receipt->user->name); ?></td>
        </tr>
        <tr>
            <td><label for="price_sum">Cost </label></td>
            <td><input type="text" name="price_sum" 
                value="<?php echo e($receipt->price_sum); ?>"/></td>
        </tr>
        <tr>
            <td><label for="description">Description</label></td>
            <td>
                <textarea cols="30" rows="8" name="description" 
                value="<?php echo e($receipt->description); ?>"><?php echo e($receipt->description); ?></textarea>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><button type="submit">Update</button></td>
        </tr>
    </table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>