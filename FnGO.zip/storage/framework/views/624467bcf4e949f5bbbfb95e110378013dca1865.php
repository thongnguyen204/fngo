<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/tour.css')); ?>" rel="stylesheet">

<div class="container create-form-container rounded bg-white">
    <div class="green-bar rounded-top"></div>
    <h1 class="d-flex justify-content-center ">
        <span style="padding-left: 20px;padding-right: 20px;" class="sub-title-warpper"><?php echo e(__('tour.Create')); ?></span>
    </h1>
    <form style="padding: 20px" action="<?php echo e(route('tour.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="lang" name="lang" value="<?php echo e(app()->getLocale()); ?>">
        <input type="hidden" id="formType" name="formType" value="create">
            <div class="form-group row">
                <div class="col">
                    <label for="name"><?php echo e(__('tour.Title')); ?></label>
                    <input class="form-control" type="text" name="name" value="<?php echo e(old('name')); ?>"/>
                    <?php if($errors->has('name')): ?>
                        <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <div class="col">
                    <label for="price"><?php echo e(__('tour.Price')); ?></label>
                    <input class="form-control" type="number" name="price" value="<?php echo e(old('price')); ?>"/>
                    <?php if($errors->has('price')): ?>
                        <?php $__currentLoopData = $errors->get('price'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col">
                    <label for="cityProvince">Province / City</label>
                    <select class="form-control" id="cityProvince" name="cityProvince">
                        <?php $__currentLoopData = $cty_province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cityProvince): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option  value="<?php echo e($cityProvince->id); ?>"><?php echo e($cityProvince->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="col">
                    <label for="passenger_num"><?php echo e(__('tour.Number of passengers')); ?></label>
                    <input class="form-control" type="number" min="0" name="passenger_num" value="<?php echo e(old('passenger_num')); ?>"/>
                    <?php if($errors->has('passenger_num')): ?>
                        <?php $__currentLoopData = $errors->get('passenger_num'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col">
                    <label for="day_number"> <?php echo e(__('tour.Days')); ?></label></td>
                    <input class="form-control" type="number" min="0" name="day_number" value="<?php echo e(old('day_number')); ?>"/>
                    <?php if($errors->has('day_number')): ?>
                        <?php $__currentLoopData = $errors->get('day_number'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-group row">
                <div class="col">
                    <label for="departure_date"><?php echo e(__('tour.Departure date')); ?></label></td>
                    <input class="form-control" type="date" name="departure_date" value="<?php echo e(old('departure_date')); ?>"/>
                    <?php if($errors->has('departure_date')): ?>
                        <?php $__currentLoopData = $errors->get('departure_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group  row">
                <div class="col">
                    <input class="form-control " type="number" min="0" max="23" placeholder="Hour" name="departure_hour" value="<?php echo e(old('departure_hour')); ?>"/>
                </div>
                
                <div class="col">
                    <input class="form-control " type="number" min="0" max="59" placeholder="Minute" name="departure_minute" value="<?php echo e(old('departure_minute')); ?>"/>
                </div>
            
                <?php if($errors->has('departure_hour')): ?>
                    <?php $__currentLoopData = $errors->get('departure_hour'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if($errors->has('departure_minute')): ?>
                <?php $__currentLoopData = $errors->get('departure_minute'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <strong><?php echo e($error); ?></strong>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </div>

            <div class="form-group row">
                <div class="col">
                    <label for="departure_place"><?php echo e(__('tour.Departure place')); ?></label>
                    <input class="form-control" type="text" name="departure_place" value="<?php echo e(old('departure_place')); ?>"/>
                    <?php if($errors->has('departure_place')): ?>
                        <?php $__currentLoopData = $errors->get('departure_place'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <div class="col">
                    <label for="content"><?php echo e(__('tour.Content')); ?> </label>
                    <textarea class="form-control" name="content" rows="10" cols="50"><?php echo e(old('content')); ?></textarea>
                    <?php if($errors->has('content')): ?>
                        <?php $__currentLoopData = $errors->get('content'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e($error); ?></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="customFile" name="avatar" >
                <label class="custom-file-label" for="customFile"><?php echo e(__('common.Choose avatar')); ?></label>
                <?php if($errors->has('avatar')): ?>
                    <?php $__currentLoopData = $errors->get('avatar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        <h2 class="d-flex justify-content-center"><?php echo e(__('tour.Schedule')); ?></h2>
        
        <div class="form-group" id="day"></div>
        <?php if($errors->has('subTripTitle.*')): ?>
            
            error
        <?php endif; ?>
        <div class="d-flex justify-content-end">
            <button class="btn btn-primary" type="button" id="addDay"><?php echo e(__('tour.Add')); ?></button>
            <button class="btn btn-secondary" type="button" id="removeDay"><?php echo e(__('tour.Remove')); ?></button>
            <button class="btn btn-success" type="submit"><?php echo e(__('tour.Init')); ?></button>
        </div>
    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>