<?php $__env->startSection('dashboard'); ?>
<div class="container-fluid">
    <h1 style="display: none" data-value="<?php echo e($year); ?>" id="title"><?php echo e($year); ?></h1>
    <div class="row">
        <div class="col-12 col-sm-12 col-md-9">
          <canvas id="myChart" style="width:100%;"></canvas>
        </div>
        <div class="col-12 col-sm-12 col-md-3 d-flex justify-content-center align-items-center">
          <div style="text-align: center;" class="row ">
            <div class="col-12 col-sm-12">
              <h3><?php echo e($year); ?></h3>
            </div>
            <div class="col-12 col-sm-12">
              <h1><?php echo e($receipt->money($total)); ?></h1>
            </div>
          </div>
        </div>
  
      </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
              <tr>
                <th scope="col"><?php echo e(__('common.Month')); ?></th>
                <th scope="col"><?php echo e(__('common.Income1')); ?></th>
                
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($month['month']); ?>/<?php echo e($year); ?></th>
                    <td data-month="<?php echo e($month['month']); ?>" data-value="<?php echo e($month['income']); ?>"><?php echo e($receipt->money($month['income'])); ?></td> 
                </tr>
                  
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
          </table>
      </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    var listMonth = [];
    var listIncome = [];
    $("table tbody tr td").each(function(){
        var month = $(this).data('month');
        listMonth.push(month);
        var income = $(this).data('value');
        listIncome.push(income);
    });
    var element = $('#title').data('value');
    console.log(listMonth);
    var xValues = listMonth;
    var yValues = listIncome;
    new Chart("myChart", {
      type: "line",
      data: {
        labels: xValues,
        datasets: [{
          fill: false,
          lineTension: 0,
          backgroundColor: "rgba(0,0,255,1.0)",
          borderColor: "rgba(0,0,255,0.1)",
          data: yValues
        }]
      },
      options: {
        legend: {display: false},
        title: {
            display: true,
            text: element,
        }
      }
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>