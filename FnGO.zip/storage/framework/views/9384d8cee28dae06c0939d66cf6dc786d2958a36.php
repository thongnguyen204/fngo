<?php $__env->startSection('content'); ?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@600&display=swap" rel="stylesheet">

<link href="<?php echo e(asset('css/hotel.css')); ?>" rel="stylesheet">



<div>
    <?php echo $__env->make('layouts.onlySearchBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<div style="max-width: 1300px;" class="container sort">

    <div class="row">
        <div class="col"></div>
        <div class="col d-flex justify-content-end">
            <div class="btn-group">
                <button type="button" class="btn btn-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <?php echo e(__('common.place')); ?>

                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <button onclick="place(0)" class="dropdown-item" type="button"><?php echo e(__('common.All')); ?></button>
                    <?php $__currentLoopData = $CityProvinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CityProvince): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button onclick="place(<?php echo e($CityProvince->id); ?>)" class="dropdown-item" type="button"><?php echo e($CityProvince->name); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
            <div class="btn-group">
                <button type="button" class="btn btn-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <?php echo e(__('common.Sort')); ?>

                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <button onclick="sort('asc')"   class="dropdown-item" type="button"><?php echo e(__('common.price-low-high')); ?></button>
                    <button onclick="sort('desc')"  class="dropdown-item" type="button"><?php echo e(__('common.price-high-low')); ?></button>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div class="title-top-hotel">
    <div style="max-width: 1300px" class="container">
        <i class="bi bi-house-door-fill"></i>
        <?php echo e(__('hotel.Hotel')); ?>

    </div>
</div>

<div style="max-width: 1300px;" class="container">
    <div id="change">
        <div class="row">
            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card col-md-4">
                <div style="padding: 10px" class="card-img-top">
                    <a href="<?php echo e(route('hotel.show',$hotel)); ?>">
                        <img loading="lazy" alt="hotek Image" class="img_fluid rounded pictrure"
                            src="<?php echo e($hotel->avatar); ?>">
                    </a>
                </div>
                <div class="card-body hotel-info">
                    <div class="row">
                        <a href="<?php echo e(route('hotel.show',$hotel)); ?>">
                            <div class="col-md-12 hotel-name-index"><?php echo e($hotel->name); ?></div>
                        </a>
                    </div>

                    
                    
                </div>
                <div class="card-footer">
                    <span class="">
                        <i class="bi bi-geo-alt-fill"></i>
                        <?php echo e($hotel->CityProvince->name); ?>

                    </span>
                    <div id="money" class="float-right" style="width: 130px"><?php echo e($hotel->money($hotel->price)); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php echo e($hotels->links()); ?>

</div>
<script>
    function sort(type){
        
        keyword = $("input[name=search]").val();
        // product_type = $('input[name="searchOptions"]:checked').val();
        product_type = 'hotel';
        console.log(product_type);
        
        $.ajax({
            url: "sort",
            type:'POST',
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",
                "keyword": keyword,
                "product_type": product_type,
                "sort_type":type,
            }
        }).done(function(respone){
            // console.log(respone);
            
            $("#change").empty();
            $("#change").html(respone);
        });
    }

    function place(place_id){
        
        
        // keyword = $("input[name=search]").val();
        
        product_type = 'hotel';
        // console.log(place_id);
        
        $.ajax({
            url: "place/"+place_id+"/"+product_type,
            type:'GET',
            
        }).done(function(respone){
            // console.log(respone);
            
            $("#change").empty();
            $("#change").html(respone);
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>