<div class="row">
    <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card col-6 col-sm-4 col-md-3">
        <div style="padding: 10px" class="card-img-top">
            <a href="<?php echo e(route('tour.show',$trip)); ?>">
                <img loading="lazy" alt="tour Image" class="img-fluid rounded pictrure" src="<?php echo e($trip->avatar); ?>">
            </a>

        </div>
        <div class="card-body tour-info">
            <div class="row">
                <a href="<?php echo e(route('tour.show',$trip)); ?>">
                    <div class="col-md-12 tour-name""><?php echo e($trip->name); ?></div>
                </a>
            </div>

            <div class="row">
                <div class="col">
                    <i class="bi bi-geo-alt-fill"></i><?php echo e($trip->CityProvince->name); ?>

                </div>
                
            </div>
        </div>
        <div class="card-footer">
            <div id="money" class="float-right" style="width: 130px"><?php echo e($trip->money($trip->price)); ?></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>