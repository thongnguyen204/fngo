<?php $__env->startSection('dashboard'); ?>

<div class="container">
    
    <h1 id="date" data-date="<?php echo e($day); ?>/<?php echo e($month); ?>/<?php echo e($year); ?>"><?php echo e($day); ?>/<?php echo e($month); ?>/<?php echo e($year); ?></h1>
    <canvas id="bar-chart" style="width:100%;"></canvas>

    <div class="table-responsive">
        <table class="table">
            <thead>
              <tr>
                <th scope="col">Receipt's ID</th>
                <th scope="col"><?php echo e(__('common.Income1')); ?></th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">#<?php echo e($receipt->id); ?></th>
                        <td data-id="<?php echo e($receipt->id); ?>" data-value="<?php echo e($receipt->price_sum); ?>"><?php echo e($receipt->money($receipt->price_sum)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
      </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    var listId = [];
    var listIncome = [];
    $("table tbody tr td").each(function(){
        var id = $(this).data('id');
        listId.push('#'+id);
        var income = $(this).data('value');
        listIncome.push(income);
    });
    console.log(listId);
    

    function random_rgba() {
    var o = Math.round, r = Math.random, s = 255;
    return 'rgba(' + o(r()*s) + ',' + o(r()*s) + ',' + o(r()*s) + ',0.2)';
    }
    function random_rgb() {
    var o = Math.round, r = Math.random, s = 255;
    return 'rgba(' + o(r()*s) + ',' + o(r()*s) + ',' + o(r()*s) + ',1)';
    }
    var date = $('#date').data('date');
    console.log(date);
    new Chart(document.getElementById("bar-chart"), {
    type: 'bar',
    data: {
      labels: listId,
      datasets: [
        {
          label: "Income (VND)",
          data: listIncome,
          backgroundColor: random_rgba(),
            borderColor: random_rgb(),
                borderWidth: 1
        }
      ]
    },
    options: {
      legend: { display: false },
      scales:{
        yAxes: [{
            ticks: {
                beginAtZero: true}
            }]
      },
      title: {
        display: true,
        text: date,
      }
    }
});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>