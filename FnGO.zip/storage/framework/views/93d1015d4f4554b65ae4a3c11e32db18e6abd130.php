

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/hotel.css')); ?>" rel="stylesheet">

<input type="hidden" id="lang" name="lang" value="<?php echo e(app()->getLocale()); ?>">

<div class="container create-form-container rounded bg-white">
    <div class="blue-bar rounded-top"></div>
    <h1 class="d-flex justify-content-center">
        <span style="padding-left: 20px;padding-right: 20px;" class="sub-title-warpper"><?php echo e(__('hotel.Edit')); ?></span>
    </h1>
    <form style="padding: 20px" action="<?php echo e(route('room.update',$room)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" name="hotel_id" value="<?php echo e($hotel->id); ?>">
        <div class="form-group row">
            <div class="col">
                <label for="name"><?php echo e(__('room.Name')); ?></label>
                <input class="form-control" type="text" name="name" value="<?php echo e($room->name); ?>" />
                <?php if($errors->has('name')): ?>
                    <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-8">
                <div class="input-group">
                    <div class="input-group-prepend">
                    <span class="input-group-text" id="">Bed</span>
                    </div>
                    <select class="form-control" name="bed_num" >
                        
                        
                        <option <?php if($room->bed[0] == '1'): ?>
                            selected
                        <?php endif; ?> value="1">1</option>
                        <option <?php if($room->bed[0] == '2'): ?>
                            selected
                        <?php endif; ?> value="2">2</option>
                    </select>
                    <select  class="form-control" name="bed_type">
                        
                        <option <?php if($room->bed[2] == '1'): ?>
                            selected
                        <?php endif; ?> value="1">single</option>
                        <option <?php if($room->bed[2] == '2'): ?>
                            selected
                        <?php endif; ?> value="2">double</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Area</span>
                    </div>
                    <input type="number" value="<?php echo e($room->area); ?>" name="area" class="form-control" >
                    <div class="input-group-append">
                        <span class="input-group-text">sqm</span>
                    </div>
                    </div>
            </div>
        </div> 
        <div class="form-group row">
            <div class="col-md-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Price</span>
                    </div>
                    <input value="<?php echo e($room->price); ?>" type="number" name="price" class="form-control">
                    </div>
            </div>
            <div class="col-md-6 d-flex align-items-center">
                <span style="margin-right: 50px">
                    <label class="checkbox-inline">
                        <input <?php if($room->refund == 1): ?>
                            checked
                        <?php endif; ?> style="margin-right: 10px" type="checkbox" name="refund" value="1">Refundable
                    </label>
                </span>
                <span style="margin-right: 10px">
                    <label class="checkbox-inline">
                        <input <?php if($room->breakfast == 1): ?>
                        checked
                    <?php endif; ?> style="margin-right: 10px" type="checkbox" name="breakfast" value="1">With breakfast
                    </label>
                </span>
                    
            </div>
        </div>
        
        
        <div class="form-group row">
            <div class="col">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="customFile" name="avatar" >
                    <label class="custom-file-label" for="customFile"><?php echo e(__('hotel.Choose avatar')); ?></label>
                    <?php if($errors->has('avatar')): ?>
                        <?php $__currentLoopData = $errors->get('avatar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="d-flex justify-content-end">
            
            <button class="btn btn-primary" type="submit"><?php echo e(__('hotel.Update')); ?></button>
            </div>
        </div>

</div>

</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>