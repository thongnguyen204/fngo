<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hotel</title>
</head>
<body>
    <h1>Hotels</h1>
    <a href="<?php echo e(route('hotel.create')); ?>">Add hotel</a>
    <table>
        <tr>
            <th>Name</th>
            <th>Average price</th>
            <th></th>
        </tr>
    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><a href="<?php echo e(route('hotel.show',$hotel)); ?>"><?php echo e($hotel->name); ?></a></td>
        <td><?php echo e($hotel->price_avg); ?></td>
        <td><a href="<?php echo e(route('hotel.edit',$hotel->id)); ?>">edit</a></td>
        <td>
            <form action="<?php echo e(route('hotel.destroy',$hotel)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit">Delete</button>
            </form>
        </td>
    </tr>
            
            
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($hotels->links()); ?>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>