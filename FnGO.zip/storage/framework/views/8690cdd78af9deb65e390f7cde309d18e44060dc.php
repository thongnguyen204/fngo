<?php $__env->startSection('content'); ?>


<body>
    <h1>Edit receipt detail</h1>
    <form action="<?php echo e(route('receipt-detail.update'
    ,$receiptDetail)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <table>
            <tr>
                <td>Service ID</td>
                <td><?php echo e($receiptDetail->service_id); ?></td>
            </tr>
            <tr>
                <td>Category</td>
                <td><?php echo e($receiptDetail->category); ?></td> 
            </tr>
            <tr>
                <td>Price</td>
                <td><?php echo e($receiptDetail->unit_price); ?></td> 
            </tr>
            <tr>
                <td><label for="quantity">Quantity </label></td>
                <td><input type="text" name="quantity" 
                    value="<?php echo e($receiptDetail->quantity); ?>"/></td>
            </tr>
            
            <tr>
                <td></td>
                <td><button type="submit">Update</button></td>
            </tr>
        </table>
    </form>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>